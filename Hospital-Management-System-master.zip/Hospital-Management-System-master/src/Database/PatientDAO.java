package Database;

import Backend.Patient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

//patient db functionalities class
public class PatientDAO {
    //method to add a new patient ot  db
    public static void insertPatient(String fullName, String username, LocalDate dob, String gender, String address,
                                     String phone, String email, String password, String bloodGroup,
                                     String allergies, String diseases) throws SQLException {

        String query = "INSERT INTO patients (full_name, username, dob, gender, address, phone, email, password, blood_group, allergies, diseases) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, fullName);
            stmt.setString(2, username);
            stmt.setDate(3, java.sql.Date.valueOf(dob));
            stmt.setString(4, gender);
            stmt.setString(5, address);
            stmt.setString(6, phone);
            stmt.setString(7, email);
            stmt.setString(8, password);
            stmt.setString(9, bloodGroup);
            stmt.setString(10, allergies);
            stmt.setString(11, diseases);

            stmt.executeUpdate();
        }
    }

    //delete a patient based on email
    public static boolean deletePatientByEmail(String email) throws SQLException {
        Connection conn = DBUtil.getConnection();
        String query = "DELETE FROM patients WHERE email = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, email);
        int rows = stmt.executeUpdate();
        return rows > 0;
    }

    //get patient details using email passed to method when user logsin
    public static Patient getPatientByEmail(String email) {
        Patient patient = null;
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patients WHERE email = ?")) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                patient = new Patient();
                patient.setPatientId(rs.getInt("patient_id"));
                patient.setName(rs.getString("full_name"));
                patient.setEmail(rs.getString("email"));
                patient.setPassword(rs.getString("password"));
                patient.setDob(String.valueOf(rs.getDate("dob").toLocalDate()));
                patient.setGender(rs.getString("gender"));
                patient.setAddress(rs.getString("address"));
                patient.setPhone(rs.getString("phone"));
                patient.setBloodGroup(rs.getString("blood_group"));
                patient.setAllergies(rs.getString("allergies"));
                patient.setDiseases(rs.getString("diseases"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        //return the patient details
        return patient;
    }

    //patient data returned based on id
    public static Patient getPatientById(int id) {
        String query = "SELECT * FROM patients WHERE patient_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Patient patient = new Patient();
                patient.setPatientId(rs.getInt("patient_id"));
                patient.setName(rs.getString("full_name"));
                patient.setUsername(rs.getString("username"));
                patient.setDob(rs.getString("dob"));
                patient.setGender(rs.getString("gender"));
                patient.setAddress(rs.getString("address"));
                patient.setPhone(rs.getString("phone"));
                patient.setEmail(rs.getString("email"));
                patient.setPassword(rs.getString("password"));
                patient.setBloodGroup(rs.getString("blood_group"));
                patient.setAllergies(rs.getString("allergies"));
                patient.setDiseases(rs.getString("diseases"));
                return patient;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    //return list of all patients in db
    public static List<Patient> getAllPatients() {
        //list to store patients
        List<Patient> patients = new ArrayList<>();
        String query = "SELECT * FROM patients";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Patient patient = new Patient();
                patient.setPatientId(rs.getInt("patient_id")); // adjust if your column name is different
                patient.setName(rs.getString("full_name"));
                patient.setUsername(rs.getString("username"));
                patient.setDob(rs.getString("dob"));
                patient.setGender(rs.getString("gender"));
                patient.setAddress(rs.getString("address"));
                patient.setPhone(rs.getString("phone"));
                patient.setEmail(rs.getString("email"));
                patient.setPassword(rs.getString("password"));
                patient.setBloodGroup(rs.getString("blood_group"));
                patient.setAllergies(rs.getString("allergies"));
                patient.setDiseases(rs.getString("diseases"));

                //add patien object to list
                patients.add(patient);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        //return the list
        return patients;
    }
}
