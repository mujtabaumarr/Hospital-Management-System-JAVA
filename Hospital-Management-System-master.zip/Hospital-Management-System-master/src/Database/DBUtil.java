package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//general db utilities class holding connection details of db
public class DBUtil {
    //db details are device specific so need to be changed based on device sql settings
    private static final String URL = "jdbc:mysql://localhost:3306/nust_medical";
    private static final String USER = "root"; // change if needed
    //usual seecs MySQL password can be uncommented if seecs db used
    //private static final String PASSWORD = "seecs@123";
    private static final String PASSWORD = "AhmadQasim4321";//change if needed

    //method to connect to db using db details above
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}