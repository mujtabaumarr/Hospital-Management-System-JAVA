package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.time.format.DateTimeFormatter;

//vitals class to store structure and data of each patients vitals
public class Vitals {
    public int patient_id;
    public String date;
    public int heartRate;
    public int oxygen;
    public double temp;
    public int bpSys;
    public int bpDia;
    public String alert;

    //constructor
    public Vitals(int patient_id, String date, int heartRate, int oxygen, double temp, int bpSys, int bpDia, String alert) {
        this.patient_id = patient_id;
        this.date = date;
        this.heartRate = heartRate;
        this.oxygen = oxygen;
        this.temp = temp;
        this.bpSys = bpSys;
        this.bpDia = bpDia;
        this.alert = generateAlert();
    }

    //getter setter methods
    public int getPatient_id() { return patient_id; }

    public String getDate() {
        return date;
    }

    public int getHeartRate() {
        return heartRate;
    }

    public int getOxygen() {
        return oxygen;
    }

    public double getTemp() {
        return temp;
    }

    public int getBpSys() {
        return bpSys;
    }

    public int getBpDia() {
        return bpDia;
    }

    public String getAlert() {
        return alert;
    }


    //method returns list of all patients vitals
    public static List<Vitals> getAllVitals() {
        List<Vitals> vitalsList = new ArrayList<>();

        String query = "SELECT * FROM vitals";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int patId = rs.getInt("patient_id");
                LocalDate localDate = rs.getDate("date").toLocalDate();
                String date = localDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                //String date = rs.getDate("date").toLocalDate()); // or format manually if it's a Date
                int heartRate = rs.getInt("heart_rate");
                int oxygen = rs.getInt("oxygen");
                double temp = rs.getDouble("temp");
                int bpSys = rs.getInt("bp_systolic");
                int bpDia = rs.getInt("bp_diastolic");

                //add data from db to new vitals object and then store in list
                Vitals v = new Vitals(patId, date, heartRate, oxygen, temp, bpSys, bpDia, null); // alert will auto generate
                vitalsList.add(v);
            }

        } catch (Exception e) { //if error occurs print a message
            System.out.println("Error getting vitals: " + e.getMessage());
        }

        //return the list
        return vitalsList;
    }

    //get patient email from db to be used for when vitals need to be returned in other classes using email
    public static String getPatientEmail(int patientId) {
        String email = null;
        String query = "SELECT email FROM patients WHERE patient_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                email = rs.getString("email");
            }

        } catch (Exception e) {
            System.out.println("Error retrieving patient email: " + e.getMessage());
        }

        return email;
    }

    //get all vitals of the patient using id
    public static List<Vitals> getAllVitals(int patientId) {
        //array list to store vitals of patient
        List<Vitals> vitalsList = new ArrayList<>();

        //query pased to sql
        String query = "SELECT * FROM vitals WHERE patient_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();

            //get data from db and enter into local variables
            while (rs.next()) {
                String date = rs.getString("date"); // or format manually if it's a Date
                int heartRate = rs.getInt("heart_rate");
                int oxygen = rs.getInt("oxygen");
                double temp = rs.getDouble("temp");
                int bpSys = rs.getInt("bp_systolic");
                int bpDia = rs.getInt("bp_diastolic");

                //vitals object stores local variables and object is then passed to list
                Vitals v = new Vitals(patientId, date, heartRate, oxygen, temp, bpSys, bpDia, null); // alert will auto generate
                vitalsList.add(v);
            }

        } catch (Exception e) { //catch sql error
            System.out.println("Error getting vitals: " + e.getMessage());
        }

        //return list
        return vitalsList;
    }


    //generates an alert if vitals deviate from a certain range
    private String generateAlert() {
        List<String> alerts = new ArrayList<>();
        if (heartRate < 60 || heartRate > 100) alerts.add("Abnormal Heart Rate");
        if (oxygen < 90) alerts.add("Low Oxygen");
        if (temp < 36.1 || temp > 37.8) alerts.add("Abnormal Temperature");
        if (bpSys < 90 || bpSys > 140) alert += "Systolic pressure out of range. ";
        if (bpDia < 60 || bpDia > 90) alert += "Diastolic pressure out of range. ";
        return String.join(", ", alerts);
    }


}