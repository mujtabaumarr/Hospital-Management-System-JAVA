package Database;

import Backend.ChatMessage;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

//chat db functionality class
public class ChatDAO {

    //method to store send message in db
    public static boolean sendMessage(ChatMessage msg) {
        String query = "INSERT INTO messages (sender_id, receiver_id, sender_role, message, timestamp, delivered_status, read_status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, msg.getSenderId());
            stmt.setInt(2, msg.getReceiverId());
            stmt.setString(3, msg.getSenderRole());
            stmt.setString(4, msg.getMessage());
            stmt.setTimestamp(5, Timestamp.valueOf(msg.getTimestamp()));
            stmt.setBoolean(6, false); // initially not delivered
            stmt.setBoolean(7, false); // initially not read

            return stmt.executeUpdate() > 0;
        } catch (Exception e) { //cathc sql error
            e.printStackTrace();
            return false;
        }
    }

    //returns list of all sent messages in that conversation
    public static List<ChatMessage> getChatHistory(int doctorId, int patientId) {
        //array list of chat messages
        List<ChatMessage> chat = new ArrayList<>();
        //query slects only the messages b/w the patient and doctor passed to method
        String query = "SELECT * FROM messages WHERE " +
                "(sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) " +
                "ORDER BY timestamp";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, doctorId);
            stmt.setInt(2, patientId);
            stmt.setInt(3, patientId);
            stmt.setInt(4, doctorId);

            ResultSet rs = stmt.executeQuery();
            //creates a new chat message object and stores it in list
            while (rs.next()) {
                chat.add(new ChatMessage(
                        rs.getInt("sender_id"),
                        rs.getInt("receiver_id"),
                        rs.getString("sender_role"),
                        rs.getString("message"),
                        rs.getTimestamp("timestamp").toLocalDateTime(),
                        rs.getBoolean("delivered_status"),
                        rs.getBoolean("read_status")
                ));
            }

            markAsDelivered(doctorId, patientId);

        } catch (Exception e) { //cathc sql error
            e.printStackTrace();
        }

        //return arraylist
        return chat;//
    }

    //returns list of newly sent messages for that chat
    public static List<ChatMessage> getNewMessages(int doctorId, int patientId, LocalDateTime since) {
        //list to store messages
        List<ChatMessage> messages = new ArrayList<>();
        //query gets new messages based on time stamp
        String query = "SELECT * FROM messages WHERE " +
                "((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) " +
                "AND timestamp > ? ORDER BY timestamp ASC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, doctorId);
            stmt.setInt(2, patientId);
            stmt.setInt(3, patientId);
            stmt.setInt(4, doctorId);
            stmt.setTimestamp(5, Timestamp.valueOf(since));

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                //new chat message object stores data from db
                ChatMessage msg = new ChatMessage(
                        rs.getInt("sender_id"),
                        rs.getInt("receiver_id"),
                        rs.getString("sender_role"),
                        rs.getString("message"),
                        rs.getTimestamp("timestamp").toLocalDateTime(),
                        rs.getBoolean("delivered_status"),
                        rs.getBoolean("read_status")
                );
                messages.add(msg); //object added to list
            }

            markAsDelivered(doctorId, patientId); //messages delivered

        } catch (SQLException e) { //cathc error of db
            e.printStackTrace();
        }
        //return array list
        return messages;
    }

    //marks messages as seen by the current user when chat opened based on message id
    public static boolean markMessageAsSeen(int messageId) {
        String query = "UPDATE messages SET read_status = ? WHERE message_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setBoolean(1, true); // Mark as read
            stmt.setInt(2, messageId); // Use the correct column name 'id'

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    //marks messages as sent for patient or doctor that sends them
    private static void markAsDelivered(int doctorId, int patientId) {
        String query = "UPDATE messages SET delivered_status = TRUE " +
                "WHERE receiver_id = ? AND sender_id = ? AND delivered_status = FALSE";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, doctorId);
            stmt.setInt(2, patientId);
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}