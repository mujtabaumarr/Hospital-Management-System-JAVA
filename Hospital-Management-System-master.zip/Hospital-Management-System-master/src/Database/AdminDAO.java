package Database;

import Backend.Admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

//class for all admin database functionality
public class AdminDAO {

    // Insert new admin into the database
    public static void insertAdmin(String fullName, String username, LocalDate dob, String gender, String address,
                                   String phone, String email, String password, String position,
                                   String department, double salary) throws SQLException {

        //query sent to db
        String query = "INSERT INTO admins (full_name, username, dob, gender, address, phone, email, password, position, department, salary) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            //setting all data to db from passed variables
            stmt.setString(1, fullName);
            stmt.setString(2, username);
            stmt.setDate(3, java.sql.Date.valueOf(dob));
            stmt.setString(4, gender);
            stmt.setString(5, address);
            stmt.setString(6, phone);
            stmt.setString(7, email);
            stmt.setString(8, password);
            stmt.setString(9, position);
            stmt.setString(10, department);
            stmt.setDouble(11, salary);

            stmt.executeUpdate();
        }
    }

    // Delete admin by email that just executes the query to delete that admins row from the db
    public static boolean deleteAdminByEmail(String email) throws SQLException {
        String query = "DELETE FROM admins WHERE email = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            int rows = stmt.executeUpdate();
            return rows > 0;
        }
    }

    // Get admin by email
    public static Admin getAdminByEmail(String email) throws SQLException {
        String query = "SELECT * FROM admins WHERE email = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                //returns an admin class object by setting the attributes with the data from db
                return new Admin(
                        rs.getInt("employee_id"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getString("password")
                );
            }
        }
        return null;
    }

    // Get list of all admins
    public static List<Admin> getAllAdmins() {
        //array list of admin class that stores all the admins returned by the sql query
        List<Admin> admins = new ArrayList<>();
        String query = "SELECT * FROM admins";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                //setting data from the query to the new admin clas object
                Admin admin = new Admin();
                admin.setId(rs.getInt("employee_id"));
                admin.setFullName(rs.getString("full_name"));
                admin.setUsername(rs.getString("username"));
                admin.setDob(rs.getDate("dob").toLocalDate());
                admin.setGender(rs.getString("gender"));
                admin.setAddress(rs.getString("address"));
                admin.setPhone(rs.getString("phone"));
                admin.setEmail(rs.getString("email"));
                admin.setPassword(rs.getString("password"));
                admin.setPosition(rs.getString("position"));
                admin.setDepartment(rs.getString("department"));
                admin.setSalary(rs.getDouble("salary"));

                admins.add(admin);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        //return the arraylist of the admins
        return admins;
    }
}