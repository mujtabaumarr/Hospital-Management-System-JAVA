package Database;

import Backend.Doctor;
import Backend.Patient;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

//doctor database functionality
public class DoctorDAO {

    // Method to get only doctor names
    public static List<String> getAllDoctorNames() throws SQLException {
        List<String> doctorNames = new ArrayList<>();

        String query = "SELECT full_name FROM doctors";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                doctorNames.add(rs.getString("full_name"));
            }
        }

        return doctorNames;
    }

    // Method to get full doctor objects
    public static List<Doctor> getAllDoctors() {
        List<Doctor> doctors = new ArrayList<>();
        String query = "SELECT * FROM doctors";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Doctor doctor = new Doctor();
                doctor.setId(rs.getInt("doctor_id"));
                doctor.setFullName(rs.getString("full_name"));
                doctor.setUsername(rs.getString("username"));
                doctor.setDob(rs.getDate("dob").toLocalDate());
                doctor.setGender(rs.getString("gender"));
                doctor.setAddress(rs.getString("address"));
                doctor.setPhone(rs.getString("phone"));
                doctor.setEmail(rs.getString("email"));
                doctor.setPassword(rs.getString("password"));
                doctor.setPmdcNumber(rs.getString("pmdc_no"));
                doctor.setAvailabilityHours(rs.getString("availability_hours"));
                doctor.setSalary(rs.getDouble("salary"));
                doctor.setQualification(rs.getString("qualification"));
                doctor.setSpeciality(rs.getString("speciality"));
                doctor.setExperience(rs.getString("experience"));

                doctors.add(doctor);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return doctors;
    }

    // Helper method to validate if doctor is old enough
    public static boolean isValidDoctorAge(LocalDate dob) {
        LocalDate today = LocalDate.now();
        int age = today.getYear() - dob.getYear();
        if (dob.plusYears(age).isAfter(today)) {
            age--; // Correct for not having had birthday yet this year
        }
        return age >= 24; // Assuming doctors must be at least 24 years old
    }

    // Get doctor by email
    public static Doctor getDoctorByEmail(String email) {
        Doctor doctor = null;

        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM doctors WHERE email = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                doctor = new Doctor();
                doctor.setId(rs.getInt("doctor_id"));
                doctor.setFullName(rs.getString("full_name"));
                doctor.setUsername(rs.getString("username"));
                doctor.setDob(rs.getDate("dob").toLocalDate());
                doctor.setGender(rs.getString("gender"));
                doctor.setAddress(rs.getString("address"));
                doctor.setPhone(rs.getString("phone"));
                doctor.setEmail(rs.getString("email"));
                doctor.setPassword(rs.getString("password"));
                doctor.setPmdcNumber(rs.getString("pmdc_no"));
                doctor.setAvailabilityHours(rs.getString("availability_hours"));
                doctor.setSalary(rs.getDouble("salary"));
                doctor.setQualification(rs.getString("qualification"));
                doctor.setSpeciality(rs.getString("speciality"));
                doctor.setExperience(rs.getString("experience"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return doctor;
    }

    //deleting a doctor based on email
    public static boolean deleteDoctorByEmail(String email) throws SQLException {
        Connection conn = DBUtil.getConnection();
        String query = "DELETE FROM doctors WHERE email = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, email);
        int rows = stmt.executeUpdate();
        return rows > 0;
    }

    //getting assigned patients to the doctor based on id
    public static List<Patient> getAssignedPatients(int doctorId) {
        List<Patient> patients = new ArrayList<>(); // list to store all returned patients
        String query = "SELECT p.* FROM patients p " +
                "JOIN assigned_patients ap ON p.patient_id = ap.patient_id " +
                "WHERE ap.doctor_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, doctorId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                //add data to patient object
                Patient patient = new Patient();
                patient.setPatientId(rs.getInt("patient_id"));
                patient.setName(rs.getString("full_name"));
                patient.setUsername(rs.getString("username"));
                patient.setDob(rs.getString("dob")); // you're storing dob as String
                patient.setGender(rs.getString("gender"));
                patient.setAddress(rs.getString("address"));
                patient.setPhone(rs.getString("phone"));
                patient.setEmail(rs.getString("email"));
                patient.setPassword(rs.getString("password"));
                patient.setBloodGroup(rs.getString("blood_group"));
                patient.setAllergies(rs.getString("allergies"));
                patient.setDiseases(rs.getString("diseases"));

                //add object to list
                patients.add(patient);
            }

        } catch (SQLException e) { //catch sql error
            e.printStackTrace();
        }

        //return array list
        return patients;
    }

    // Get doctor ID by name
    public static int getDoctorIdByName(String doctorName) throws SQLException {
        int doctorId = -1;

        String query = "SELECT doctor_id FROM doctors WHERE full_name = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, doctorName);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                doctorId = rs.getInt("doctor_id");
            }
        }

        return doctorId;
    }

    // Insert new doctor
    public static void insertDoctor(String fullName, String username, LocalDate dob, String gender, String address,
                                    String phone, String email, String password, String pmdc,
                                    String availability, double salary, String qualification,
                                    String speciality, String experience) throws SQLException {

        if (!isValidDoctorAge(dob)) {
            throw new IllegalArgumentException("Invalid Doctor Age: Doctor must be at least 24 years old.");
        }

        String query = "INSERT INTO doctors ( full_name, username, dob, gender, address, phone, email, password, pmdc_no, availability_hours, salary, qualification, speciality, experience)" +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, fullName);
            stmt.setString(2, username);
            stmt.setDate(3, java.sql.Date.valueOf(dob));
            stmt.setString(4, gender);
            stmt.setString(5, address);
            stmt.setString(6, phone);
            stmt.setString(7, email);
            stmt.setString(8, password);
            stmt.setString(9, pmdc);
            stmt.setString(10, availability);
            stmt.setDouble(11, salary);
            stmt.setString(12, qualification);
            stmt.setString(13, speciality);
            stmt.setString(14, experience);

            stmt.executeUpdate();
        }
    }
}