package Database;

import Backend.Assignment;
import Backend.Doctor;
import Backend.Patient;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

//db functionality class for handling and tracking doctor patient assignments
public class AssignmentDAO {

    // Method to get all doctors assigned to a patient (doctor details)
    public static List<Doctor> getAssignedDoctors(int patientId) {
        //list to store assignments
        List<Doctor> doctors = new ArrayList<>();
        String query = "SELECT d.* FROM doctors d JOIN assigned_patients ap ON d.doctor_id = ap.doctor_id WHERE ap.patient_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                //doctor object created and used to store data returned from db
                Doctor doctor = new Doctor();
                doctor.setId(rs.getInt("doctor_id"));
                doctor.setFullName(rs.getString("full_name"));
                doctor.setUsername(rs.getString("username"));
                doctor.setDob(rs.getDate("dob").toLocalDate());
                doctor.setGender(rs.getString("gender"));
                doctor.setAddress(rs.getString("address"));
                doctor.setPhone(rs.getString("phone"));
                doctor.setEmail(rs.getString("email"));
                doctor.setPassword(rs.getString("password"));
                doctor.setPmdcNumber(rs.getString("pmdc_no"));
                doctor.setAvailabilityHours(rs.getString("availability_hours"));
                doctor.setSalary(rs.getDouble("salary"));
                doctor.setQualification(rs.getString("qualification"));
                doctor.setSpeciality(rs.getString("speciality"));
                doctor.setExperience(rs.getString("experience"));

                //add object to arraylist
                doctors.add(doctor);
            }

        } catch (SQLException e) { //catch sql error
            e.printStackTrace();
        }

        //return arraylist containg doctors assigned to patient
        return doctors;
    }

    // Method to delete an assignment
    public static boolean deleteAssignment(int doctorId, int patientId) throws SQLException {
        String query = "DELETE FROM assigned_patients WHERE doctor_id = ? AND patient_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, doctorId);
            stmt.setInt(2, patientId);
            int rows = stmt.executeUpdate();

            return rows > 0;
        }
    }

    //method to return list of assigned patients to a doctor
    public static List<Patient> getAssignedPatients(int doctorId) {
        //array list to store patient list
        List<Patient> patients = new ArrayList<>();
        String query = "SELECT p.* FROM patients p " +
                "JOIN assigned_patients ap ON p.patient_id = ap.patient_id " +
                "WHERE ap.doctor_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, doctorId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                //patient object to store data returned from db
                Patient patient = new Patient();
                patient.setPatientId(rs.getInt("patient_id"));
                patient.setName(rs.getString("full_name"));
                patient.setUsername(rs.getString("username"));
                patient.setDob(rs.getString("dob")); // storing dob as String
                patient.setGender(rs.getString("gender"));
                patient.setAddress(rs.getString("address"));
                patient.setPhone(rs.getString("phone"));
                patient.setEmail(rs.getString("email"));
                patient.setPassword(rs.getString("password"));
                patient.setBloodGroup(rs.getString("blood_group"));
                patient.setAllergies(rs.getString("allergies"));
                patient.setDiseases(rs.getString("diseases"));

                //object added to arraylist
                patients.add(patient);
            }

        } catch (SQLException e) { //catch db error
            e.printStackTrace();
        }

        //return arraylist
        return patients;
    }
}