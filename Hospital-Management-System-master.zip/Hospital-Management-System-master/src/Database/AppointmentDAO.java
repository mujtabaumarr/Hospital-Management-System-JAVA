package Database;

import Backend.Appointment;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

//appointment database functionality class
public class AppointmentDAO {
    //custom variation of appointment class that includes doctor name for use in a different class
    public static class shownAppointment{
        private int id;
        private int patientId;
        private int doctorId;
        private String doctorName;
        private LocalDate date;
        private LocalTime time;
        private String status;
        private String notes;

        //constructor
        public shownAppointment(int id, int patientId, int doctorId, String doctorName,LocalDate date, LocalTime time, String status, String notes) {
            this.id = id;
            this.patientId = patientId;
            this.doctorId = doctorId;
            this.doctorName = doctorName;
            this.date = date;
            this.time = time;
            this.status = status;
            this.notes = notes;
        }

        //getter setters
        public int getId() { return id; }
        public int getPatientId() { return patientId; }
        public int getDoctorId() { return doctorId; }
        public String getDoctorName() { return doctorName; }
        public LocalDate getDate() { return date; }
        public LocalTime getTime() { return time; }
        public String getStatus() { return status; }
        public String getNotes() { return notes; }
    }
    // Method to get appointments for a specific patient
    public static List<shownAppointment> getAppointmentsForPatient(int patientId) {
        //list of appointments
        List<shownAppointment> appointments = new ArrayList<>();
        String query = "SELECT a.appointment_id, a.patient_id,a.doctor_id, d.full_name, a.appointment_date, a.appointment_time, a.status, a.notes FROM appointments a JOIN doctors d ON a.doctor_id = d.doctor_id WHERE a.patient_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();

            //setting local variables to data returned from db query
            while (rs.next()) {
                int id = rs.getInt("appointment_id");
                int patId = rs.getInt("patient_id");
                int docId = rs.getInt("doctor_id");
                String fullName = rs.getString("full_name");
                LocalDate date = rs.getDate("appointment_date").toLocalDate();
                LocalTime time = rs.getTime("appointment_time").toLocalTime();
                String status = rs.getString("status");
                String notes = rs.getString("notes");

                //addin all the data to the array list
                appointments.add(new shownAppointment(id, patId, docId, fullName, date, time, status, notes));
            }

        } catch (SQLException e) {//catch db errors
            e.printStackTrace();
        }

        //return the arraylist
        return appointments;
    }

    // Method to book an appointment and assign the doctor to the patient
    public static boolean bookAppointment(Appointment appointment) throws SQLException {
        String appointmentQuery = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, status, notes) VALUES (?, ?, ?, ?, ?, ?)";
        String assignedPatientsQuery = "INSERT INTO assigned_patients (doctor_id, patient_id) VALUES (?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement appointmentStmt = conn.prepareStatement(appointmentQuery);
             PreparedStatement assignedPatientsStmt = conn.prepareStatement(assignedPatientsQuery)) {

            // Insert into appointments table
            appointmentStmt.setInt(1, appointment.getPatientId());
            appointmentStmt.setInt(2, appointment.getDoctorId());
            appointmentStmt.setDate(3, java.sql.Date.valueOf(appointment.getDate()));
            appointmentStmt.setTime(4, java.sql.Time.valueOf(appointment.getTime()));
            appointmentStmt.setString(5, appointment.getStatus());
            appointmentStmt.setString(6, appointment.getNotes());
            int appointmentRows = appointmentStmt.executeUpdate();

            // If the appointment insertion is successful, also insert into assigned_patients
            if (appointmentRows > 0) {
                assignedPatientsStmt.setInt(1, appointment.getDoctorId());
                assignedPatientsStmt.setInt(2, appointment.getPatientId());
                int assignedPatientRows = assignedPatientsStmt.executeUpdate();

                return assignedPatientRows > 0;  // Return true if both operations are successful
            }

            return false;  // Return false if appointment insertion failed
        }
    }
    // Method to get all appointments for a specific doctor
    public static List<Appointment> getAppointmentsForDoctor(int doctorId) {
        //arraylist of appointment class storing all appointments for that docotr\or
        List<Appointment> appointments = new ArrayList<>();
        String query = "SELECT appointment_id, patient_id, doctor_id, appointment_date, appointment_time, status, notes FROM appointments WHERE doctor_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, doctorId);
            ResultSet rs = stmt.executeQuery();

            //setting local variables to data from db query
            while (rs.next()) {
                int id = rs.getInt("appointment_id");
                int patientId = rs.getInt("patient_id");
                LocalDate date = rs.getDate("appointment_date").toLocalDate();
                LocalTime time = rs.getTime("appointment_time").toLocalTime();
                String status = rs.getString("status");
                String notes = rs.getString("notes");

                //appointments list updated with data
                appointments.add(new Appointment(id, patientId, doctorId, date, time, status, notes));
            }

        } catch (SQLException e) { //catch sql error
            e.printStackTrace();
        }

        //return arraylist of appointments
        return appointments;
    }

    // Method to get all appointments for all patients, doctors
    public static List<Appointment> getAllAppointments() {
        //array list to store
        List<Appointment> appointments = new ArrayList<>();

        String query = "SELECT* FROM appointments";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                //new appointment object to store data from db
                Appointment appointment = new Appointment();

                appointment.setId(rs.getInt("appointment_id"));
                appointment.setPatientId(rs.getInt("patient_id"));
                appointment.setDoctorId(rs.getInt("doctor_id"));
                appointment.setDate(rs.getDate("appointment_date").toLocalDate());
                appointment.setTime(rs.getTime("appointment_time").toLocalTime());
                appointment.setStatus(rs.getString("status"));
                appointment.setNotes(rs.getString("notes"));

                //object passed to arraylist
                appointments.add(appointment);
            }

        } catch (Exception e) { //sql error catching
            System.out.println("Error getting appointments: " + e.getMessage());
        }

        //return array list
        return appointments;
    }

    // Method to update an appointment's status
    public static boolean updateAppointmentStatus(int appointmentId, String newStatus) {
        String query = "UPDATE appointments SET status = ? WHERE appointment_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            //sets db attributes to the ones passed to the method
            stmt.setString(1, newStatus);
            stmt.setInt(2, appointmentId);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;  // Return true if the status was successfully updated

        } catch (SQLException e) { //catch sql exception
            e.printStackTrace();
        }

        return false;  // Return false if there was an error
    }
}