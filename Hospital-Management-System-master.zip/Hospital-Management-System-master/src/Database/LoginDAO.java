package Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//database functionality to validate and allow logins
public class LoginDAO {

    //method to match login details with account types
    public static String authenticate(String email, String password) {
        // Check in patients
        if (checkCredentials("patients", email, password)) return "patient";
        // Check in doctors
        if (checkCredentials("doctors", email, password)) return "doctor";
        // Check in admins
        if (checkCredentials("admins", email, password)) return "admin";

        return null; // No matching user found
    }

    //method to match login details with stored account details in db
    private static boolean checkCredentials(String tableName, String email, String password) {
        String query = "SELECT * FROM " + tableName + " WHERE email = ? AND password = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, email);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next(); // True if user exists false if it doesnt

        } catch (SQLException e) { //catch sql error and return false if error occurs
            e.printStackTrace();
            return false;
        }
    }
}