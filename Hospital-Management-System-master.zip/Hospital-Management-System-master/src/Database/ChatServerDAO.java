package Database;

import Backend.Doctor;
import Backend.Patient;

import java.sql.*;
import java.util.*;

//class to handle database functions of chat server
public class ChatServerDAO {
    //db sign in details (need to changed based on device specific mysql settings)
    private static final String URL = "jdbc:mysql://localhost:3306/nust_medical";
    private static final String USER = "root";
    private static final String PASSWORD = "AhmadQasim4321";

    //returns map of all doctors that have patients assigned to them
    public static Map<String, Doctor> getAllDoctorsWithPatients() {
        //create new map holding doctors
        Map<String, Doctor> doctorMap = new HashMap<>();

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String doctorQuery = "SELECT * FROM doctors";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(doctorQuery);

            while (rs.next()) {
                Doctor doctor = new Doctor();
                doctor.setId(rs.getInt("doctor_id"));
                doctor.setFullName(rs.getString("full_name")); // assuming 'name' column in DB
                doctor.setEmail(rs.getString("email"));
                doctor.setPassword(rs.getString("password"));
                doctor.setPatients(new ArrayList<>());
                doctorMap.put(String.valueOf(doctor.getId()), doctor);
            }

            String mappingQuery = "SELECT ap.doctor_id, p.patient_id, p.full_name, p.email, p.password " +
                    "FROM assigned_patients ap " +
                    "JOIN patients p ON ap.patient_id = p.patient_id";

            ResultSet mappingRS = stmt.executeQuery(mappingQuery);
            while (mappingRS.next()) {
                Patient patient = new Patient();
                patient.setPatientId(mappingRS.getInt("patient_id"));
                patient.setName(mappingRS.getString("full_name"));
                patient.setEmail(mappingRS.getString("email"));
                patient.setPassword(mappingRS.getString("password"));

                String docId = String.valueOf(mappingRS.getInt("doctor_id"));
                Doctor doctor = doctorMap.get(docId);
                if (doctor != null) {
                    doctor.getPatients().add(patient);
                }
            }

        } catch (SQLException e) { //catch sql error
            e.printStackTrace();
        }

        //return the map
        return doctorMap;
    }

    //method checks if relation exists b/w passed users
    public static boolean relationshipExists(String doctorId, String patientId) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String query = "SELECT * FROM assigned_patients WHERE doctor_id = ? AND patient_id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            //passing parameters of method to db
            ps.setInt(1, Integer.parseInt(doctorId));
            ps.setInt(2, Integer.parseInt(patientId));

            ResultSet rs = ps.executeQuery();

            //returns true/false if relation exists
            return rs.next();

        } catch (Exception e) { //catch db errors
            e.printStackTrace();
            //return false if db error occurs
            return false;
        }
    }
}