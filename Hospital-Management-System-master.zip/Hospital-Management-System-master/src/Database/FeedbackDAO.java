package Database;

import Backend.Feedback;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class FeedbackDAO {
    private String doctorName;
    private String feedback;
    private String date;

    // Constructor for viewing feedback
    public FeedbackDAO(String doctorName, String feedback, String date) {
        this.doctorName = doctorName;
        this.feedback = feedback;
        this.date = date;
    }

    // insert feedback using Backend.Feedback model
    public static boolean insertFeedback(Feedback feedback) {
        String query = "INSERT INTO doctor_feedback (doctor_id, patient_id, feedback_date, feedback) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, feedback.getDoctorId());
            stmt.setInt(2, feedback.getPatientId());
            stmt.setDate(3, Date.valueOf(feedback.getFeedbackDate()));
            stmt.setString(4, feedback.getFeedback());

            return stmt.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    //get feedback list by patient ID
    public static List<FeedbackDAO> getFeedbackList(int patientId) {
        List<FeedbackDAO> feedbackList = new ArrayList<>();

        try (Connection conn = DBUtil.getConnection()) {
            String query = "SELECT d.full_name, f.feedback, f.feedback_date " +
                    "FROM doctor_feedback f " +
                    "JOIN doctors d ON f.doctor_id = d.doctor_id " +
                    "WHERE f.patient_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                //add to the list a feedback object using data from db query
                feedbackList.add(new FeedbackDAO(
                        rs.getString(1),   // doctor name
                        rs.getString(2),   // feedback text
                        rs.getString(3)    // feedback date
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        //return arraylist containing all feedback
        return feedbackList;
    }



    //TableView of feedbacks
    public static TableView<FeedbackDAO> getFeedbackTable(int patientId) {
        TableView<FeedbackDAO> table = new TableView<>();
        ObservableList<FeedbackDAO> data = FXCollections.observableArrayList(getFeedbackList(patientId));

        TableColumn<FeedbackDAO, String> doctorCol = new TableColumn<>("Doctor");
        doctorCol.setCellValueFactory(new PropertyValueFactory<>("doctorName"));

        TableColumn<FeedbackDAO, String> feedbackCol = new TableColumn<>("Feedback");
        feedbackCol.setCellValueFactory(new PropertyValueFactory<>("feedback"));

        TableColumn<FeedbackDAO, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        table.getColumns().addAll(doctorCol, feedbackCol, dateCol);
        table.setItems(data);

        return table;
    }

    // Getters
    public String getDoctorName() { return doctorName; }
    public String getFeedback() { return feedback; }
    public String getDate() { return date; }
}