package Database;

import Backend.Prescription;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

//db functionalities of prescriptions
public class PrescriptionDAO {

    //insert a new prescription into the db
    public static boolean insertPrescription(Prescription prescription) {
        String query = "INSERT INTO medications (patient_id, doctor_id, medicine_name, dosage, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, prescription.getPatientId());
            stmt.setInt(2, prescription.getDoctorId());
            stmt.setString(3, prescription.getMedicineName());
            stmt.setString(4, prescription.getDosage());
            stmt.setDate(5, Date.valueOf(prescription.getStartDate()));
            stmt.setDate(6, Date.valueOf(prescription.getEndDate()));

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //get prescriptions of patient based on id
    public static List<Prescription> getPrescriptionsByPatientId(int patientId) {
        //list to store patients
        List<Prescription> list = new ArrayList<>();
        String query = "SELECT * FROM medications WHERE patient_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                //add data from db to list
                list.add(new Prescription(
                        rs.getInt("medication_id"),
                        rs.getInt("patient_id"),
                        rs.getInt("doctor_id"),
                        rs.getString("medicine_name"),
                        rs.getString("dosage"),
                        rs.getDate("start_date").toLocalDate(),
                        rs.getDate("end_date").toLocalDate()
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        //retunr the list of patients
        return list;
    }

    //generates table view of patients if needed
    public static TableView<Prescription> getPrescriptionTable(int patientId) {
        TableView<Prescription> table = new TableView<>();
        ObservableList<Prescription> data = FXCollections.observableArrayList(getPrescriptionsByPatientId(patientId));

        TableColumn<Prescription, String> medCol = new TableColumn<>("Medicine");
        medCol.setCellValueFactory(new PropertyValueFactory<>("medicineName"));

        TableColumn<Prescription, String> doseCol = new TableColumn<>("Dosage");
        doseCol.setCellValueFactory(new PropertyValueFactory<>("dosage"));

        TableColumn<Prescription, LocalDate> startCol = new TableColumn<>("Start Date");
        startCol.setCellValueFactory(new PropertyValueFactory<>("startDate"));

        TableColumn<Prescription, LocalDate> endCol = new TableColumn<>("End Date");
        endCol.setCellValueFactory(new PropertyValueFactory<>("endDate"));

        table.getColumns().addAll(medCol, doseCol, startCol, endCol);
        table.setItems(data);
        return table;
    }
}