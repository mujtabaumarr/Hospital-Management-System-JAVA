package GUI;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;


import java.net.URL;

//main runnable class that inherits application and holds base GUI styling and homepage
public class App extends Application {

    //setting up stages of and parts of the window
    public static Stage primaryStage;
    private static Stage staticStage;
    private BorderPane mainLayout;
    private Scene homepageScene;
    StackPane navBar = createNavBar();

    public static Stage getPrimaryStage() {
        return staticStage;
    }

    //when started
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        staticStage = primaryStage;
        primaryStage.setTitle("MyNMC");

        // Set window icon
        Image icon = new Image(getClass().getResourceAsStream("/GUI/assets/appicon.png"));
        primaryStage.getIcons().add(icon);

        // Top Navigation Bar
        StackPane navBar = createNavBar();

        // Hero Section
        StackPane heroSection = createHeroSection();

        mainLayout = new BorderPane();
        VBox centerContent = new VBox(heroSection);
        centerContent.setSpacing(30);

        homepageScene = new Scene(mainLayout, 1200, 700); // Scene now contains the layout

        mainLayout.setTop(navBar);
        mainLayout.setCenter(centerContent);

        // Background image
        try {
            URL bgURL = getClass().getResource("/GUI/assets/background.jpg");
            if (bgURL != null) {
                Image bgImg = new Image(bgURL.toExternalForm());
                BackgroundImage bgImage = new BackgroundImage(
                        bgImg,
                        BackgroundRepeat.NO_REPEAT,
                        BackgroundRepeat.NO_REPEAT,
                        BackgroundPosition.CENTER,
                        new BackgroundSize(
                                100, 100,        // 100% width and height
                                true, true,      // width/height as percentage
                                false, true      // contain=false, cover=true (scale and crop)
                        )
                );
                mainLayout.setBackground(new Background(bgImage));
            } else {
                System.err.println("⚠️ Background image not found at: /GUI/assets/background.jpg");
            }
        } catch (Exception e) {
            System.err.println("⚠️ Error loading background image: " + e.getMessage());
        }

        primaryStage.setScene(homepageScene);
        primaryStage.show();
    }

    public static void setScene(Scene scene) {
        staticStage.setScene(scene);
    }

    //crating top red bar with main title that stays throughout app
    private StackPane createNavBar() {
        StackPane navBar = new StackPane();
        navBar.setPadding(new Insets(15));
        navBar.setPrefWidth(1200);
        navBar.setPrefHeight(100);
        navBar.setStyle("-fx-background-color: #990000;");

        // Center Logo
        Hyperlink topText = new Hyperlink("National University of Sciences & Technology");
        topText.setFont(Font.font("Georgia", FontWeight.EXTRA_BOLD, 13));
        topText.setTextFill(Color.WHITE);
        topText.setStyle("-fx-background-color: transparent; -fx-border-width: 0; -fx-padding: 0;");
        topText.setUnderline(false);
        topText.setOnAction(e -> System.out.println("Navigating to Homepage..."));

        Rectangle whiteLine = new Rectangle(300, 2);
        whiteLine.setFill(Color.WHITE);

        Hyperlink bottomText = new Hyperlink("NUST MEDICAL CENTRE");
        bottomText.setFont(Font.font("Georgia", FontWeight.BOLD, 22));
        bottomText.setTextFill(Color.WHITE);
        bottomText.setStyle("-fx-background-color: transparent; -fx-border-width: 0; -fx-padding: 0;");
        bottomText.setUnderline(false);
        bottomText.setOnAction(e -> System.out.println("Navigating to Homepage..."));

        VBox logoBox = new VBox(topText, whiteLine, bottomText);
        logoBox.setAlignment(Pos.CENTER);
        logoBox.setSpacing(4);

        HBox rightBar = new HBox();
        rightBar.setAlignment(Pos.CENTER_LEFT);
        rightBar.setPrefWidth(1200);

        Label hospitalTiming = new Label("🕒 Hospital Timing: 24 x 7");
        hospitalTiming.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        hospitalTiming.setTextFill(Color.WHITE);

        HBox leftInfoBar = new HBox(hospitalTiming);
        leftInfoBar.setAlignment(Pos.CENTER_LEFT);
        leftInfoBar.setPadding(new Insets(0, 0, 0, 10));

        Region leftSpacer = new Region();
        HBox.setHgrow(leftSpacer, Priority.ALWAYS);

        rightBar.getChildren().addAll(leftInfoBar, leftSpacer);

        navBar.getChildren().addAll(logoBox, rightBar);
        StackPane.setAlignment(logoBox, Pos.CENTER);
        StackPane.setAlignment(rightBar, Pos.CENTER_LEFT);

        return navBar;
    }

    private StackPane createHeroSection() {
        StackPane hero = new StackPane();
        hero.setPrefHeight(300);

        Image image = new Image("https://wexnermedical.osu.edu/-/media/images/wexnermedical/home/hero-banner.jpg", true);
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(1200);
        imageView.setFitHeight(300);
        imageView.setPreserveRatio(false);

        VBox content = new VBox();
        content.setAlignment(Pos.CENTER);
        content.setSpacing(10);

        Label headline = new Label("Health crisis waits for no one. Neither should you.");
        headline.setTextFill(Color.WHITE);
        headline.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        headline.setWrapText(true);
        headline.setMaxWidth(1000);
        headline.setAlignment(Pos.CENTER);

        Label subtext = new Label("Our 24/7 emergency department provides care to those in need of urgent medical care.");
        subtext.setTextFill(Color.WHITE);

        UIComponents.FancyButton loginBtn = new UIComponents.FancyButton("Log In");
        loginBtn.setTranslateY(50);
        loginBtn.setOnAction(e -> {
            Scene loginScene = new Scene(LoginWindow.getStyledLoginScene(primaryStage, homepageScene), 1200, 700);
            primaryStage.setScene(loginScene);
        });

        content.getChildren().addAll(headline, subtext, loginBtn); // ✅ replace callToAction
        hero.getChildren().addAll(imageView, content);
        return hero;


    }

    public static void main(String[] args) {
        launch(args);
    } //launch the app
}