package GUI;

import Database.AppointmentDAO;
import Database.FeedbackDAO;
import Backend.Appointment;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

//appointment view for patients
public class PatientAppointmentsView{

    private int patientId; // Assume this will be set from logged-in user's session
    private TableView<AppointmentDAO.shownAppointment> appointmentTable; // Declare the TableView for appointments
    private TableView<FeedbackDAO> feedbackTable; // Declare the TableView for feedback




    //Public method to embed this view in dashboard
    public VBox getView(Stage stage, Scene homepageScene, int patientId) {
        this.patientId = patientId;
        System.out.println(patientId);


        // === Book Appointment Section ===
        ComboBox<String> doctorComboBox = new ComboBox<>();
        doctorComboBox.setPromptText("Select Doctor");

        DatePicker appointmentDate = new DatePicker();
        appointmentDate.setPromptText("Select Date");

        TextField timeField = new TextField();
        timeField.setPromptText("Enter Time (e.g. 14:00)");

        Button bookButton = new Button("Book Appointment");

        HBox bookingSection = new HBox(10, doctorComboBox, appointmentDate, timeField, bookButton);
        bookingSection.setStyle("-fx-padding: 15px;");

        // === Appointment Table Section ===
        appointmentTable = new TableView<>();

        TableColumn<AppointmentDAO.shownAppointment, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        TableColumn<AppointmentDAO.shownAppointment, String> timeCol = new TableColumn<>("Time");
        timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));

        TableColumn<AppointmentDAO.shownAppointment, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        TableColumn<AppointmentDAO.shownAppointment, String> docCol = new TableColumn<>("Doctor");
        docCol.setCellValueFactory(new PropertyValueFactory<>("doctorName"));

        appointmentTable.getColumns().addAll(dateCol, timeCol, statusCol, docCol);

        // === Feedback Table Section ===
        feedbackTable = new TableView<>();

        TableColumn<FeedbackDAO, String> doctorCol = new TableColumn<>("Doctor");
        doctorCol.setCellValueFactory(new PropertyValueFactory<>("doctorName"));

        TableColumn<FeedbackDAO, String> feedbackCol = new TableColumn<>("Feedback");
        feedbackCol.setCellValueFactory(new PropertyValueFactory<>("feedback"));

        TableColumn<FeedbackDAO, String> dateFeedbackCol = new TableColumn<>("Date");
        dateFeedbackCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        feedbackTable.getColumns().addAll(doctorCol, feedbackCol, dateFeedbackCol);

        // === Full Layout ===
        VBox root = new VBox(20, bookingSection, appointmentTable, feedbackTable);
        root.setStyle("-fx-padding: 20px;");

        loadDoctorNames(doctorComboBox);
        loadAppointments();

        bookButton.setOnAction(e -> {
            String doctorName = doctorComboBox.getValue();
            LocalDate date = appointmentDate.getValue();
            String time = timeField.getText();

            if (doctorName == null || date == null || time.isEmpty()) {
                showAlert("Please fill all fields.");
                return;
            }

            int doctorId = getDoctorIdByName(doctorName);
            boolean success = false;
            try {
                success = bookAppointment(doctorId, date, time);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
            if (success) {
                showAlert("Appointment booked successfully!");
                loadAppointments();
            } else {
                showAlert("Error booking appointment. Try again.");
            }
        });

        return root;
    }

    // === Load doctor names into ComboBox ===
    private void loadDoctorNames(ComboBox<String> doctorComboBox) {
        try {
            List<String> doctors = Database.DoctorDAO.getAllDoctorNames();
            doctorComboBox.setItems(FXCollections.observableArrayList(doctors));
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error loading doctor names.");
        }
    }

    // === Load appointments and feedback ===
    private void loadAppointments() {
        List<AppointmentDAO.shownAppointment> appointments = AppointmentDAO.getAppointmentsForPatient(patientId);
        appointmentTable.setItems(FXCollections.observableArrayList(appointments));

        List<FeedbackDAO> feedbackList = FeedbackDAO.getFeedbackList(patientId);
        feedbackTable.setItems(FXCollections.observableArrayList(feedbackList));
    }

    // === Book appointment in DB ===
    private boolean bookAppointment(int doctorId, LocalDate date, String time) throws SQLException {
        LocalTime localTime = LocalTime.parse(time);
        Appointment appointment = new Appointment(0, patientId, doctorId, date, localTime, "Scheduled", null);
        return Database.AppointmentDAO.bookAppointment(appointment);
    }

    // === Get doctor ID by name ===
    private int getDoctorIdByName(String doctorName) {
        try {
            return Database.DoctorDAO.getDoctorIdByName(doctorName);
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    // === Alert Helper ===
    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
