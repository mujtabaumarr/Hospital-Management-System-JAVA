package GUI;

import Database.ChatServerDAO;
import Backend.Doctor;
import Backend.Patient;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.Map;

//class to check all relationships and validate for chat functionality
public class ChatServerPane extends VBox {

    private TextArea outputArea;
    private TextField doctorIdField;
    private TextField patientIdField;

    public ChatServerPane() {
        setPadding(new Insets(20));
        setSpacing(10);

        Label title = new Label("🗨️ Chat Server Manager");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Button viewRelationshipsBtn = new Button("View Doctor-Patient Relationships");
        Button validateRelationshipBtn = new Button("Validate Relationship");
        doctorIdField = new TextField();
        doctorIdField.setPromptText("Enter Doctor ID");
        patientIdField = new TextField();
        patientIdField.setPromptText("Enter Patient ID");

        outputArea = new TextArea();
        outputArea.setEditable(false);
        outputArea.setWrapText(true);
        outputArea.setPrefHeight(300);

        viewRelationshipsBtn.setOnAction(e -> viewDoctorPatientRelationships());
        validateRelationshipBtn.setOnAction(e -> validateRelationship());

        HBox validationBox = new HBox(10, doctorIdField, patientIdField, validateRelationshipBtn);

        getChildren().addAll(title, viewRelationshipsBtn, validationBox, outputArea);
    }

    private void viewDoctorPatientRelationships() {
        outputArea.clear();
        Map<String, Doctor> doctorMap = ChatServerDAO.getAllDoctorsWithPatients();

        if (doctorMap.isEmpty()) {
            outputArea.appendText("No doctors found in the system.\n");
            return;
        }

        boolean found = false;
        for (Doctor doctor : doctorMap.values()) {
            outputArea.appendText("Doctor: " + doctor.getFullName() + " (ID: " + doctor.getId() + ")\n");
            if (doctor.getPatients().isEmpty()) {
                outputArea.appendText("  - No patients assigned.\n");
            } else {
                for (Patient p : doctor.getPatients()) {
                    outputArea.appendText("  - Patient: " + p.getName() + " (ID: " + p.getPatientId() + ")\n");
                    found = true;
                }
            }
            outputArea.appendText("\n");
        }

        if (!found) {
            outputArea.appendText("No doctor-patient relationships established.\n");
        }
    }

    //validating a relationship
    private void validateRelationship() {
        //get data from text fields
        String doctorId = doctorIdField.getText().trim();
        String patientId = patientIdField.getText().trim();

        if (doctorId.isEmpty() || patientId.isEmpty()) {
            outputArea.appendText("Please enter both Doctor ID and Patient ID.\n");
            return;
        }

        //tell user if relation exists after checking from db
        boolean exists = ChatServerDAO.relationshipExists(doctorId, patientId);
        if (exists) {
            outputArea.appendText("✅ VALID: The doctor-patient relationship exists.\n");
        } else {
            outputArea.appendText("❌ INVALID: No such relationship exists.\n");
        }
    }
}