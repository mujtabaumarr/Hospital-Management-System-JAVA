package GUI;

import javafx.animation.ScaleTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import javafx.animation.ScaleTransition;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import static GUI.App.primaryStage;

//general helper class for helpful and reusable gui methiods used in different classes
public class UIComponents {
    //to create a custom style button
    public static class FancyButton extends Button {

        private final Rotate rotateX = new Rotate(0, Rotate.X_AXIS);
        private final Rotate rotateY = new Rotate(0, Rotate.Y_AXIS);

        public FancyButton(String text) {
            super(text);

            // Styling
            this.setFont(Font.font("Arial", FontWeight.BOLD, 17));
            this.setStyle(getNormalStyle());
            this.setPrefHeight(45);
            this.setPrefWidth(150);

            // Drop shadow for 3D feel
            DropShadow shadow = new DropShadow();
            shadow.setColor(Color.rgb(0, 0, 0, 0.3));
            shadow.setOffsetX(2);
            shadow.setOffsetY(2);
            this.setEffect(shadow);

            // Add 3D rotation transforms
            getTransforms().addAll(rotateX, rotateY);

            // Init animations and hover effects
            initAnimations();
        }

        //button animations on hover and press
        private void initAnimations() {
            ScaleTransition scaleDown = new ScaleTransition(Duration.millis(100), this);
            scaleDown.setToX(0.95);
            scaleDown.setToY(0.95);

            ScaleTransition scaleUp = new ScaleTransition(Duration.millis(100), this);
            scaleUp.setToX(1);
            scaleUp.setToY(1);

            this.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
                setStyle(getHoverStyle());
            });

            this.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
                setStyle(getNormalStyle());
                rotateX.setAngle(0);
                rotateY.setAngle(0);
            });

            this.addEventHandler(MouseEvent.MOUSE_PRESSED, e -> scaleDown.playFromStart());
            this.addEventHandler(MouseEvent.MOUSE_RELEASED, e -> scaleUp.playFromStart());

            // 3D tilt effect
            this.addEventHandler(MouseEvent.MOUSE_MOVED, this::apply3DTilt);
        }

        //apply effect on mouse detection
        private void apply3DTilt(MouseEvent e) {
            double centerX = getWidth() / 2.0;
            double centerY = getHeight() / 2.0;
            double deltaX = e.getX() - centerX;
            double deltaY = e.getY() - centerY;

            double maxAngle = 10;
            double tiltX = (deltaY / centerY) * -maxAngle;
            double tiltY = (deltaX / centerX) * maxAngle;

            rotateX.setAngle(tiltX);
            rotateY.setAngle(tiltY);
        }

        //normal state
        private String getNormalStyle() {
            return "-fx-background-color: linear-gradient(to bottom right, #cc0000, #ff4d4d);" +
                    "-fx-text-fill: white;" +
                    "-fx-font-weight: bold;" +
                    "-fx-background-radius: 10;";
        }

        //mouse hovering style
        private String getHoverStyle() {
            return "-fx-background-color: linear-gradient(to bottom right, #990000, #e60000);" +
                    "-fx-text-fill: white;" +
                    "-fx-font-weight: bold;" +
                    "-fx-background-radius: 10;";
        }
    }

    //reusable nav bar method
    public static StackPane createNavBar(Stage stage, Scene homepageScene) {
        StackPane navBar = new StackPane();
        navBar.setPadding(new Insets(15));
        navBar.setPrefWidth(1200);
        navBar.setPrefHeight(100);
        navBar.setStyle("-fx-background-color: #990000;");

        // Center Logo
        Hyperlink topText = new Hyperlink("National University of Sciences & Technology");
        topText.setFont(Font.font("Georgia", FontWeight.EXTRA_BOLD, 13));
        topText.setTextFill(Color.WHITE);
        topText.setStyle("-fx-background-color: transparent; -fx-border-width: 0; -fx-padding: 0;");
        topText.setUnderline(false);
        topText.setOnAction(e -> stage.setScene(homepageScene));

        Rectangle whiteLine = new Rectangle(300, 2);
        whiteLine.setFill(Color.WHITE);

        Hyperlink bottomText = new Hyperlink("NUST MEDICAL CENTRE");
        bottomText.setFont(Font.font("Georgia", FontWeight.BOLD, 22));
        bottomText.setTextFill(Color.WHITE);
        bottomText.setStyle("-fx-background-color: transparent; -fx-border-width: 0; -fx-padding: 0;");
        bottomText.setUnderline(false);
        bottomText.setOnAction(e -> stage.setScene(homepageScene));

        VBox logoBox = new VBox(topText, whiteLine, bottomText);
        logoBox.setAlignment(Pos.CENTER);
        logoBox.setSpacing(4);

        HBox rightBar = new HBox();
        rightBar.setAlignment(Pos.CENTER_LEFT);
        rightBar.setPrefWidth(1200);

        Label hospitalTiming = new Label("🕒 Hospital Timing: 24 x 7");
        hospitalTiming.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        hospitalTiming.setTextFill(Color.WHITE);

        Button backButton = new Button("← Back");
        backButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        backButton.setTextFill(Color.WHITE);
        backButton.setStyle("-fx-background-color: transparent; -fx-border-color: white; -fx-border-radius: 4; -fx-padding: 6 12;");
        backButton.setOnAction(e -> {
            stage.setScene(homepageScene);
        });

        HBox leftInfoBar = new HBox(backButton);
        leftInfoBar.setAlignment(Pos.CENTER_LEFT);
        leftInfoBar.setPadding(new Insets(0, 0, 0, 10));

        Region leftSpacer = new Region();
        HBox.setHgrow(leftSpacer, Priority.ALWAYS);
        rightBar.getChildren().addAll(leftInfoBar, leftSpacer);

        navBar.getChildren().addAll(logoBox, rightBar);
        StackPane.setAlignment(logoBox, Pos.CENTER);
        StackPane.setAlignment(rightBar, Pos.CENTER_LEFT);

        return navBar;
    }
}