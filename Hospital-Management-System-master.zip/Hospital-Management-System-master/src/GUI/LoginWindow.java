package GUI;

import Backend.Doctor;
import Database.LoginDAO;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

//login page class
public class LoginWindow {

    //style of login page defined
    public static BorderPane getStyledLoginScene(Stage primaryStage, Scene homepageScene) {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f5f5f5;");

        Label featureHeader = new Label(
                "Please do not use this app to send messages that require urgent attention. " +
                        "For urgent medical matters call your health care provider's office or dial 115 in an emergency."
        );
        featureHeader.setFont(Font.font("Georgia", FontWeight.EXTRA_BOLD, 18));
        featureHeader.setTextFill(Color.WHITE);
        featureHeader.setWrapText(true);
        featureHeader.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        featureHeader.setAlignment(Pos.CENTER);
        featureHeader.setStyle("-fx-background-color: #990000; -fx-padding: 16 30 16 30; -fx-background-radius: 0;");

        StackPane navBar = UIComponents.createNavBar(primaryStage, homepageScene);
        root.setTop(navBar);

        HBox headerContainer = new HBox(featureHeader);
        headerContainer.setAlignment(Pos.CENTER);
        headerContainer.setStyle("-fx-background-color: #990000;");
        headerContainer.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(featureHeader, Priority.ALWAYS);

        GridPane featureGrid = new GridPane();
        featureGrid.setHgap(20);
        featureGrid.setVgap(20);
        featureGrid.setPadding(new Insets(20));
        featureGrid.setAlignment(Pos.CENTER);

        featureGrid.add(createFeatureBox("🧑‍⚕️ Communicate with your doctor", "Get answers to your medical questions from the comfort of your own home"), 0, 0);
        featureGrid.add(createFeatureBox("📊 Access your test results", "No more waiting – view your results and your doctor's comments"), 1, 0);
        featureGrid.add(createFeatureBox("💊 Request prescription refills", "Send a refill request for any of your medications"), 0, 1);
        featureGrid.add(createFeatureBox("📅 Manage appointments", "Schedule or view past and upcoming appointments"), 1, 1);

        VBox leftPane = new VBox(25, headerContainer, featureGrid);
        leftPane.setAlignment(Pos.TOP_CENTER);
        leftPane.setPadding(new Insets(40));
        leftPane.setStyle("-fx-background-color: white;");
        leftPane.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(leftPane, Priority.ALWAYS);

        VBox rightPane = getLoginPane();
        rightPane.setMaxWidth(300);
        rightPane.setStyle("-fx-background-color: #ffffff; -fx-background-radius: 10; -fx-padding: 30;");

        HBox forgotLinks = new HBox(20, createLink("Forgot username?"), createLink("Forgot password?"));
        forgotLinks.setAlignment(Pos.CENTER);

        Button createAccountBtn = createTealButton("CREATE YOUR ACCOUNT");
        createAccountBtn.setOnMouseEntered(e -> createAccountBtn.setStyle("-fx-background-color: #1e4d37; -fx-text-fill: white; -fx-background-radius: 6;"));
        createAccountBtn.setOnMouseExited(e -> createAccountBtn.setStyle("-fx-background-color: #2d6a4f; -fx-text-fill: white; -fx-background-radius: 6;"));
        createAccountBtn.setOnAction(e -> {
            Scene signupScene = new Scene(SignupSelection.getSelectionPane(primaryStage, homepageScene), 1200, 700);
            primaryStage.setScene(signupScene);
        });

        VBox rightWrapper = new VBox(10);
        rightWrapper.setAlignment(Pos.CENTER);
        rightWrapper.getChildren().addAll(
                rightPane,
                forgotLinks,
                spacer(),
                boldLabel("New User?"),
                createAccountBtn
        );

        HBox mainLayout = new HBox(50, leftPane, rightWrapper);
        mainLayout.setPadding(new Insets(40));
        mainLayout.setAlignment(Pos.CENTER);
        HBox.setHgrow(mainLayout, Priority.ALWAYS);

        root.setCenter(mainLayout);
        return root;
    }

    public static VBox getLoginPane() {
        return getLoginPane("Your Account");
    }

    public static VBox getLoginPane(String role) {
        VBox loginPane = new VBox();
        loginPane.setPadding(new Insets(20));
        loginPane.setSpacing(10);
        loginPane.setAlignment(Pos.CENTER);
        loginPane.setStyle("-fx-background-color: rgba(255,255,255,0.85);");

        Label title = new Label(role);
        title.setFont(Font.font("Arial", FontWeight.BOLD, 22));
        title.setTextFill(Color.web("#990000"));

        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.setMaxWidth(220);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.setMaxWidth(220);

        Button loginBtn = new Button("Sign in");
        loginBtn.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        loginBtn.setStyle("-fx-background-color: #2d6a4f; -fx-text-fill: white; -fx-background-radius: 5;");
        loginBtn.setMaxWidth(220);
        loginBtn.setOnMouseEntered(e -> loginBtn.setStyle("-fx-background-color: #1e4d37; -fx-text-fill: white; -fx-background-radius: 5;"));
        loginBtn.setOnMouseExited(e -> loginBtn.setStyle("-fx-background-color: #2d6a4f; -fx-text-fill: white; -fx-background-radius: 5;"));

        Spinner<Void> spinner = new Spinner<>();
        spinner.setStyle("-fx-opacity: 0;");
        spinner.setPrefWidth(40);
        spinner.setPrefHeight(40);

        loginBtn.setOnAction(e -> {
            spinner.setStyle("-fx-opacity: 1;");
            String email = emailField.getText();
            String password = passwordField.getText();

            new Thread(() -> {
                String authenticatedRole = LoginDAO.authenticate(email, password);
                Platform.runLater(() -> {
                    spinner.setStyle("-fx-opacity: 0;");
                    if (authenticatedRole == null) {
                        showAlert("Login Failed", "Invalid email or password.");
                    } else {
                        navigateToDashboard(authenticatedRole, email);
                    }
                });
            }).start();
        });

        loginPane.getChildren().addAll(title, emailField, passwordField, loginBtn, spinner);
        return loginPane;
    }

    private static VBox createFeatureBox(String title, String description) {
        Label titleLabel = new Label(title);
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        titleLabel.setTextFill(Color.web("#990000"));

        Label descLabel = new Label(description);
        descLabel.setFont(Font.font("Arial", 13));
        descLabel.setWrapText(true);

        VBox box = new VBox(5, titleLabel, descLabel);
        box.setPadding(new Insets(15));
        box.setStyle("-fx-background-color: #e6e6e6;");
        box.setPrefWidth(300);
        box.setPrefHeight(130);
        return box;
    }

    //style helper methods for reusable gui features
    private static Hyperlink createLink(String text) {
        Hyperlink link = new Hyperlink(text);
        link.setFont(Font.font("Arial", 12));
        link.setTextFill(Color.web("#007b8a"));
        return link;
    }

    private static Button createTealButton(String text) {
        Button button = new Button(text);
        button.setStyle("-fx-background-color: #2d6a4f; -fx-text-fill: white; -fx-background-radius: 6;");
        button.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        button.setMinWidth(220);
        return button;
    }

    private static Label boldLabel(String text) {
        Label label = new Label(text);
        label.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        label.setTextFill(Color.web("#990000"));
        return label;
    }

    private static Region spacer() {
        Region spacer = new Region();
        spacer.setMinHeight(10);
        return spacer;
    }

    //mwthod to go to different dashboards
    private static void navigateToDashboard(String role, String email) {
        switch (role) {
            case "patient" -> showPatientDashboard(email);
            case "doctor" -> showDoctorDashboard(email);
            case "admin" -> showAdminDashboard(email);
        }
    }

    //patient dashboard naviagted to
    private static void showPatientDashboard(String email) {
        try {
            Stage currentStage = App.getPrimaryStage();
            Scene homepageScene = currentStage.getScene();
            BorderPane dashboard = PatientDashboard.getDashboard(currentStage, homepageScene, email);
            Scene dashboardScene = new Scene(dashboard, 1200, 700);
            currentStage.setScene(dashboardScene);
            currentStage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to load Patient Dashboard.");
        }
    }

    //patient dashboard shown
    private static void showDoctorDashboard(String email) {
        try {
            Stage currentStage = App.getPrimaryStage();
            Scene homepageScene = currentStage.getScene();
            BorderPane dashboard = DoctorDashboard.getDashboard(currentStage, homepageScene,email);
            Scene dashboardScene = new Scene(dashboard, 1200, 700);
            currentStage.setScene(dashboardScene);
            currentStage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to load Doctor Dashboard.");
        }
    }

    //admin dashboard shown
    private static void showAdminDashboard(String email) {
        try {
            Stage currentStage = App.getPrimaryStage();
            Scene homepageScene = currentStage.getScene();
            BorderPane dashboard = AdminDashboard.getDashboard(currentStage, homepageScene,email);
            Scene adminScene = new Scene(dashboard, 1200, 700);
            currentStage.setScene(adminScene);
            currentStage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to load Admin Dashboard.");
        }
    }

    //alert helper method to reuse whenever alerts generated
    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}