package GUI;

import Backend.*;
import Database.*;
import java.util.Properties;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;

import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;
import java.util.Properties;
import java.awt.*;
import java.net.URI;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static GUI.DoctorForm.showAlert;

//doctor dashboard class, shown after doctors login
public class DoctorDashboard {

    private static VBox mainContent;  // Declare mainContent as a VBox

    //method to setup window
    public static BorderPane getDashboard(Stage stage, Scene homepageScene, String doctorEmail) {
        //setup window and find doctor using email
        Doctor doctor = DoctorDAO.getDoctorByEmail(doctorEmail);

        if (doctor == null) {
            System.out.println("Doctor not found!");
            return new BorderPane(); // Empty pane if doctor is not found
        }



        // Main layout for the dashboard
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(0));
        mainContent = new VBox(10);  // Initialize it as a VBox (or another container type)
        mainContent.setPadding(new Insets(20));  // Set padding or other properties as needed




        // Reuse the Navbar for Doctor Dashboard
        StackPane navBar = UIComponents.createNavBar(stage, homepageScene);
        //StackPane navBar = createDoctorNavBar(primaryStage);
        root.setTop(navBar);

        // Create a VBox for buttons (these buttons will open new scenes in the center area)
        VBox buttonBox = new VBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(40));

        buttonBox.getChildren().addAll(
                createButton("View My Patients", () -> setCenterContent(stage, root, doctor, "patients")),
                createButton("View Patient Data", () -> setCenterContent(stage, root, doctor, "patientData")),
                createButton("View Appointments", () -> setCenterContent(stage, root, doctor, "appointments")),
                createButton("Provide Feedback", () -> setCenterContent(stage, root, doctor, "feedback")),
                createButton("Issue Prescription", () -> setCenterContent(stage, root, doctor, "prescription")),
                createButton("Monitor Vital Signs", () -> setCenterContent(stage, root, doctor, "vitals")),
                createButton("Chat with Patient", () -> setCenterContent(stage, root, doctor, "chat")),
                createButton("Start Video Consultation", () -> setCenterContent(stage, root, doctor, "videoConsultation")),
                createButton("Logout", () -> logout(stage))
        );

        VBox layout = new VBox(30);
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setPadding(new Insets(30));
        layout.getChildren().addAll(buttonBox);

        // Set the default content
        setCenterContent(stage, root, doctor, "patients");

        root.setCenter(layout);
        return root;
    }

    //when patient data view button pressed this method is called
    private static VBox createPatientDataView(Doctor doctor) {
        TableView<Patient> table = new TableView<>();

        // Define columns, their names and what they store
        TableColumn<Patient, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Patient, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));

        TableColumn<Patient, String> genderCol = new TableColumn<>("Gender");
        genderCol.setCellValueFactory(new PropertyValueFactory<>("gender"));

        TableColumn<Patient, String> dobCol = new TableColumn<>("Date of Birth");
        dobCol.setCellValueFactory(new PropertyValueFactory<>("dob"));

        TableColumn<Patient, String> phoneCol = new TableColumn<>("Phone");
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));

        TableColumn<Patient, String> addressCol = new TableColumn<>("Address");
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));

        TableColumn<Patient, String> bloodGroupCol = new TableColumn<>("Blood Group");
        bloodGroupCol.setCellValueFactory(new PropertyValueFactory<>("bloodGroup"));

        TableColumn<Patient, String> allergiesCol = new TableColumn<>("Allergies");
        allergiesCol.setCellValueFactory(new PropertyValueFactory<>("allergies"));

        TableColumn<Patient, String> diseasesCol = new TableColumn<>("Existing Diseases");
        diseasesCol.setCellValueFactory(new PropertyValueFactory<>("existingDiseases"));

        // Add columns to table
        table.getColumns().addAll(
                nameCol, emailCol, genderCol, dobCol, phoneCol,
                addressCol, bloodGroupCol, allergiesCol, diseasesCol
        );

        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Fetch assigned patients from db
        List<Patient> patients = DoctorDAO.getAssignedPatients(doctor.getId());
        table.getItems().addAll(patients);

        Label heading = new Label("Detailed Patient Data");
        heading.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        VBox layout = new VBox(15, heading, table);
        layout.setPadding(new Insets(20));

        return layout;
    }

    //create the doctor feedback view, when relevant button pressed this method is called
    private static VBox createFeedbackView(Doctor doctor) {
        VBox root = new VBox(10);
        root.setPadding(new Insets(20));

        //labels fields and buttons to create data entry menu
        Label title = new Label("Write Feedback for Patient");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        TextField patientIdField = new TextField();
        patientIdField.setPromptText("Patient ID");

        TextArea feedbackArea = new TextArea();
        feedbackArea.setPromptText("Write feedback...");
        feedbackArea.setWrapText(true);

        Button submitButton = new Button("Submit Feedback");

        //when submit pressed
        submitButton.setOnAction(e -> {
            try {
                //get data from fields
                int patientId = Integer.parseInt(patientIdField.getText());
                String feedbackText = feedbackArea.getText();

                //check if data has been entered
                if (feedbackText.isEmpty()) {
                    showAlert("Validation Error", "Feedback cannot be empty.");
                    return;
                }

                //create new feedback object
                Backend.Feedback feedback = new Backend.Feedback(
                        doctor.getId(),
                        patientId,
                        LocalDate.now(),
                        feedbackText
                );

                //add data to db
                boolean success = FeedbackDAO.insertFeedback(feedback);

                //if adding data succeds or fails:
                if (success) {
                    showAlert("Success", "Feedback submitted successfully.");
                    patientIdField.clear();
                    feedbackArea.clear();
                } else {
                    showAlert("Error", "Failed to submit feedback.");
                }

            } catch (NumberFormatException ex) { //validating id entry
                showAlert("Invalid Input", "Patient ID must be a number.");
            }
        });

        root.getChildren().addAll(title, patientIdField, feedbackArea, submitButton);
        return root;
    }

    //prescription form window when button pressed
    private static VBox createPrescriptionForm(Doctor doctor) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER_LEFT);

        //heading, buttons fields setup
        Label heading = new Label("Write a Prescription");
        heading.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField patientIdField = new TextField();
        patientIdField.setPromptText("Patient ID");

        TextField medicineNameField = new TextField();
        medicineNameField.setPromptText("Medicine Name");

        TextField dosageField = new TextField();
        dosageField.setPromptText("Dosage");

        DatePicker startDatePicker = new DatePicker();
        startDatePicker.setPromptText("Start Date");

        DatePicker endDatePicker = new DatePicker();
        endDatePicker.setPromptText("End Date");

        Button submitButton = new Button("Submit Prescription");
        Label statusLabel = new Label();

        submitButton.setOnAction(e -> { //when submit pressed
            try {
                //get data from fields
                int patientId = Integer.parseInt(patientIdField.getText());
                String medicine = medicineNameField.getText();
                String dosage = dosageField.getText();
                LocalDate start = startDatePicker.getValue();
                LocalDate end = endDatePicker.getValue();

                if (medicine.isEmpty() || dosage.isEmpty() || start == null || end == null) {
                    statusLabel.setText("Please fill all fields.");
                    return;
                }

                //create new prescription object using data
                Prescription prescription = new Prescription(
                        0, patientId, doctor.getId(),
                        medicine, dosage, start, end
                );

                //add data to db
                boolean success = PrescriptionDAO.insertPrescription(prescription);
                if (success) { //if added to db
                    statusLabel.setText("Prescription saved successfully!");
                    patientIdField.clear();
                    medicineNameField.clear();
                    dosageField.clear();
                    startDatePicker.setValue(null);
                    endDatePicker.setValue(null);
                } else {    //if db addition fails
                    statusLabel.setText("Error saving prescription.");
                }

            } catch (NumberFormatException ex) {
                statusLabel.setText("Invalid Patient ID."); //entry validation
            }
        });

        layout.getChildren().addAll(
                heading,
                new Label("Patient ID:"), patientIdField,
                new Label("Medicine Name:"), medicineNameField,
                new Label("Dosage:"), dosageField,
                new Label("Start Date:"), startDatePicker,
                new Label("End Date:"), endDatePicker,
                submitButton, statusLabel
        );

        return layout;
    }

    //vitals view that shows all vitals
    private static VBox createVitalsView(Doctor doctor) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        //headings and setting up table of vitals for each patient based on id
        Label heading = new Label("All Patient Vitals");
        heading.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TableView<Vitals> table = new TableView<>();
        List<Vitals> vitalsList = Vitals.getAllVitals(); //get list of all vitals
        ObservableList<Vitals> data = FXCollections.observableArrayList(vitalsList);

        TableColumn<Vitals, Integer> idCol = new TableColumn<>("Patient ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("patient_id"));

        TableColumn<Vitals, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        TableColumn<Vitals, Integer> hrCol = new TableColumn<>("Heart Rate");
        hrCol.setCellValueFactory(new PropertyValueFactory<>("heartRate"));

        TableColumn<Vitals, Integer> oxygenCol = new TableColumn<>("Oxygen");
        oxygenCol.setCellValueFactory(new PropertyValueFactory<>("oxygen"));

        TableColumn<Vitals, Double> tempCol = new TableColumn<>("Temperature");
        tempCol.setCellValueFactory(new PropertyValueFactory<>("temp"));

        TableColumn<Vitals, Integer> sysCol = new TableColumn<>("BP Sys");
        sysCol.setCellValueFactory(new PropertyValueFactory<>("bpSys"));

        TableColumn<Vitals, Integer> diaCol = new TableColumn<>("BP Dia");
        diaCol.setCellValueFactory(new PropertyValueFactory<>("bpDia"));

        TableColumn<Vitals, String> alertCol = new TableColumn<>("Alerts");
        alertCol.setCellValueFactory(new PropertyValueFactory<>("alert"));

        //add all columns to table and add the data to it from list
        table.getColumns().addAll(idCol, dateCol, hrCol, oxygenCol, tempCol, sysCol, diaCol, alertCol);
        table.setItems(data);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        //email sending configuration:
        class EmailUtil {
            public void sendEmail(String toEmail, String subject, String body) throws Exception {
                // SMTP server setup (Gmail)
                String host = "smtp.gmail.com";  // Change to your SMTP provider if needed
                String fromEmail = doctor.getEmail();  // sender email
                String password = doctor.getPassword();  // sender email password (uses app-specific password for Gmail)

                Properties props = System.getProperties();
                props.put("mail.smtp.host", host);
                props.put("mail.smtp.port", "587");
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");

                Session session = Session.getInstance(props, new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(fromEmail, password);
                    }
                });

                // Create email message
                MimeMessage message = new MimeMessage(session);
                message.setFrom(new InternetAddress(fromEmail));
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
                message.setSubject(subject);
                message.setText(body);

                // Send the email
                Transport.send(message);
                System.out.println("Email sent successfully to " + toEmail);
            }

            // Validate email format
            public static boolean isValidEmail(String email) {
                String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
                return email.matches(emailRegex);
            }
        }

        //Send Alert Button
        Button sendAlertButton = new Button("Send Alert");

        sendAlertButton.setOnAction(e -> {
            Vitals selectedVitals = table.getSelectionModel().getSelectedItem();
            if (selectedVitals == null) {
                showAlert("No Selection", "Please select a patient from the table.");
                return;
            }
            int patientId = selectedVitals.getPatient_id();

            String patientEmail = Vitals.getPatientEmail(patientId); // You must implement this
            if (patientEmail == null || !EmailUtil.isValidEmail(patientEmail)) {
                showAlert("Invalid Email", "This patient does not have a valid email address.");
                return;
            }

            try {
                //message setup and sending
                String subject = "Health Alert from Your Doctor (TEST ALERT NOT ACTUAL EMERGENCY)";
                String body = "Dear patient,\n\nYour latest vitals indicate abnormal values and so doctors of NUST Medical Centre advise that you book an appointment.\n\nRegards,\nDr. " + doctor.getFullName();
                EmailUtil emailUtil = new EmailUtil();
                emailUtil.sendEmail(patientEmail, subject, body);
                showAlert("Success", "Alert email sent to " + patientEmail);
            } catch (Exception ex) {
                showAlert("Error", "Failed to send email: " + ex.getMessage());
            }
        });

        layout.getChildren().addAll(heading, table, sendAlertButton);
        return layout;
    }

    //show alert helper method
    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    //chat interface
    private static VBox createChatInterface(Doctor doctor) {
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setStyle("-fx-background-color: #f5f5f5;");

        Label title = new Label("Chat with Your Patients");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        ComboBox<Patient> patientCombo = new ComboBox<>();
        patientCombo.setPromptText("Select a patient");
        patientCombo.setPrefWidth(300);

        // Get the assigned patients for the doctor
        List<Patient> patients = AssignmentDAO.getAssignedPatients(doctor.getId()); // Use doctor.getId() here
        if (patients != null && !patients.isEmpty()) {
            patientCombo.getItems().addAll(patients);
        } else {
            patientCombo.setDisable(true);  // Disable the ComboBox if no patients are available
            patientCombo.setPromptText("No patients available");
        }

        TextArea chatArea = new TextArea();
        chatArea.setEditable(false);
        chatArea.setWrapText(true);
        chatArea.setPrefHeight(400);
        chatArea.setStyle("-fx-control-inner-background: #ecf0f1; -fx-font-size: 14px;");

        HBox inputBox = new HBox(10);
        inputBox.setAlignment(Pos.CENTER);
        TextField inputField = new TextField();
        inputField.setPromptText("Type your message...");
        inputField.setPrefWidth(300);
        inputField.setStyle("-fx-background-radius: 8px; -fx-font-size: 14px;");
        Button sendBtn = new Button("Send");
        sendBtn.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-background-radius: 8px;");
        inputBox.getChildren().addAll(inputField, sendBtn);

        // State
        final int[] currentPatientId = {-1};
        final LocalDateTime[] lastMessageTime = {LocalDateTime.MIN};
        final Set<String> displayedMessageIds = new HashSet<>(); // Avoid duplicates

        // Real-time polling for new messages
        Timeline messagePoller = new Timeline(new KeyFrame(Duration.seconds(3), ev -> {
            if (currentPatientId[0] != -1) {
                List<ChatMessage> newMessages = ChatDAO.getNewMessages(doctor.getId(), currentPatientId[0], lastMessageTime[0]);

                for (ChatMessage msg : newMessages) {
                    String uniqueId = msg.getMessageId() + msg.getTimestamp().toString(); // Unique identifier
                    if (!displayedMessageIds.contains(uniqueId)) {
                        String sender = msg.getSenderRole().equals("doctor") ? "You" : "Patient";
                        String formattedTime = msg.getTimestamp().toLocalTime().withNano(0).toString();
                        String status = msg.isReadStatus() ? "✓✓" : "✓"; // Seen = double tick

                        chatArea.appendText("[" + formattedTime + "] " + sender + ": " + msg.getMessage() + " " + status + "\n");
                        displayedMessageIds.add(uniqueId);
                        lastMessageTime[0] = msg.getTimestamp();

                        // Optionally mark as seen
                        if (!msg.isReadStatus() && !msg.getSenderRole().equals("doctor")) {
                            ChatDAO.markMessageAsSeen(msg.getMessageId());
                        }
                    }
                }
            }
        }));
        messagePoller.setCycleCount(Animation.INDEFINITE);
        messagePoller.play();

        // Load chat when patient is selected
        patientCombo.setOnAction(e -> {
            Patient selected = patientCombo.getValue();
            if (selected != null) {
                chatArea.clear();
                displayedMessageIds.clear();
                currentPatientId[0] = selected.getPatientId();
                lastMessageTime[0] = LocalDateTime.MIN;

                List<ChatMessage> history = ChatDAO.getChatHistory(doctor.getId(), currentPatientId[0]);
                for (ChatMessage msg : history) {
                    String sender = msg.getSenderRole().equals("doctor") ? "You" : "Patient";
                    String formattedTime = msg.getTimestamp().toLocalTime().withNano(0).toString();
                    String status = msg.getSenderRole().equals("doctor") ? (msg.isReadStatus() ? "✓✓" : "✓") : "";

                    chatArea.appendText("[" + formattedTime + "] " + sender + ": " + msg.getMessage() + " " + status + "\n");
                    displayedMessageIds.add(msg.getMessageId() + msg.getTimestamp().toString());
                    lastMessageTime[0] = msg.getTimestamp();

                    // Optionally mark old unread messages as seen
                    if (!msg.isReadStatus() && !msg.getSenderRole().equals("doctor")) {
                        ChatDAO.markMessageAsSeen(msg.getMessageId());
                    }
                }
            }
        });

        // Send message
        sendBtn.setOnAction(e -> {
            String message = inputField.getText().trim();
            if (!message.isEmpty() && currentPatientId[0] != -1) {
                LocalDateTime now = LocalDateTime.now();
                // Pass deliveredStatus and readStatus as false initially
                ChatMessage msg = new ChatMessage(
                        doctor.getId(),          // Sender ID (Doctor)
                        currentPatientId[0],     // Receiver ID (Patient)
                        "doctor",                // Sender Role (Doctor)
                        message,                 // Message content
                        now,                     // Timestamp of message
                        false,                   // Delivered status (initially false)
                        false                    // Read status (initially false)
                );
                if (ChatDAO.sendMessage(msg)) {
                    chatArea.appendText("[" + now.toLocalTime().withNano(0) + "] You: " + message + " ✓\n");
                    inputField.clear();
                    lastMessageTime[0] = now;
                    displayedMessageIds.add(msg.getMessageId() + now.toString());
                }
            }
        });

        layout.getChildren().addAll(title, patientCombo, chatArea, inputBox);
        return layout;
    }

    //appointment view
    private static VBox createAppointmentsView(Doctor doctor) {
        Label heading = new Label("My Appointments");
        heading.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        //table of appointments
        TableView<Appointment> table = new TableView<>();

        //add columns
        TableColumn<Appointment, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Appointment, Integer> patientIdCol = new TableColumn<>("Patient ID");
        patientIdCol.setCellValueFactory(new PropertyValueFactory<>("patientId"));

        TableColumn<Appointment, LocalDate> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        TableColumn<Appointment, LocalTime> timeCol = new TableColumn<>("Time");
        timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));

        TableColumn<Appointment, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        TableColumn<Appointment, String> notesCol = new TableColumn<>("Notes");
        notesCol.setCellValueFactory(new PropertyValueFactory<>("notes"));

        TableColumn<Appointment, Void> updateCol = new TableColumn<>("Actions");

        //table has buttons that allow to view patient or update appointment status
        updateCol.setCellFactory(param -> new TableCell<>() {
            private final Button updateStatusBtn = new Button("Update Status");
            private final Button viewBtn = new Button("View Patient");

            {
                updateStatusBtn.setOnAction(event -> {
                    Appointment appointment = getTableView().getItems().get(getIndex());
                    TextInputDialog dialog = new TextInputDialog(appointment.getStatus());
                    dialog.setTitle("Update Status");
                    dialog.setHeaderText("Update Appointment Status");
                    dialog.setContentText("New status:");

                    Optional<String> result = dialog.showAndWait();
                    result.ifPresent(newStatus -> {
                        boolean updated = AppointmentDAO.updateAppointmentStatus(appointment.getId(), newStatus);
                        if (updated) {
                            appointment.setStatus(newStatus);
                            table.refresh();
                            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Status updated.");
                            alert.showAndWait();
                        } else {
                            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to update.");
                            alert.showAndWait();
                        }
                    });
                });

                viewBtn.setOnAction(event -> { //when view patient pressed
                    Appointment appointment = getTableView().getItems().get(getIndex());
                    int patientId = appointment.getPatientId();
                    Patient patient = PatientDAO.getPatientById(patientId); // make sure you have this method
                    if (patient != null) {
                        Alert info = new Alert(Alert.AlertType.INFORMATION);
                        info.setTitle("Patient Details");
                        info.setHeaderText("Patient ID: " + patientId);
                        info.setContentText("Name: " + patient.getName() + "\nEmail: " + patient.getEmail() + "\nGender: " + patient.getGender());
                        info.showAndWait();
                    }
                });
            }

            HBox pane = new HBox(10, updateStatusBtn, viewBtn);

            //update status
            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(pane);
                }
            }
        });

        //add columns and data to table from db
        table.getColumns().addAll(idCol, patientIdCol, dateCol, timeCol, statusCol, notesCol, updateCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        List<Appointment> appointments = AppointmentDAO.getAppointmentsForDoctor(doctor.getId());
        table.getItems().addAll(appointments);

        VBox layout = new VBox(10, heading, table);
        layout.setPadding(new Insets(20));
        return layout;
    }

    // Dynamic content setter
    private static void setCenterContent(Stage primaryStage, BorderPane root, Doctor doctor, String action) {
        VBox contentLayout = new VBox();

        switch (action) {
            case "patients":
                contentLayout = createPatientView(primaryStage, doctor);
                break;
            case "patientData":
                contentLayout = createPatientDataView(doctor);
                break;
            case "appointments":
                contentLayout = createAppointmentsView(doctor);
                break;
            case "feedback":
                contentLayout = createFeedbackView(doctor);
                break;
            case "prescription":
                contentLayout = createPrescriptionForm(doctor); // form for adding prescription
                break;
            case "vitals":
                contentLayout = createVitalsView(doctor);
                break;
            case "chat":
                contentLayout = createChatInterface(doctor);
                break;

            case "videoConsultation":
                try {
                    // Open Google Meet in the default browser
                    Desktop.getDesktop().browse(new URI("https://meet.google.com/"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
        }

        root.setCenter(contentLayout);
    }

    //patient view shown
    private static VBox createPatientView(Stage primaryStage, Doctor doctor) {
        TableView<Patient> table = new TableView<>();

        // Columns
        TableColumn<Patient, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Patient, String> genderCol = new TableColumn<>("Gender");
        genderCol.setCellValueFactory(new PropertyValueFactory<>("gender"));

        TableColumn<Patient, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));

        table.getColumns().addAll(nameCol, genderCol, emailCol);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Fetch patients assigned to this doctor
        List<Patient> patients = DoctorDAO.getAssignedPatients(doctor.getId());
        table.getItems().addAll(patients);

        Label heading = new Label("Assigned Patients");
        heading.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        VBox layout = new VBox(15, heading, table);
        layout.setPadding(new Insets(20));

        return layout;
    }

    //reusable method to create a stylised button
    private static UIComponents.FancyButton createButton(String text, Runnable action) {
        UIComponents.FancyButton button = new UIComponents.FancyButton(text);
        button.setPrefWidth(300); // Optional override
        button.setOnAction(e -> action.run());
        return button;
    }

    //logout button goes back to sign in page
    private static void logout(Stage primaryStage) {
        primaryStage.setScene(new Scene(LoginWindow.getStyledLoginScene(primaryStage, null), 1200, 700));
    }
}