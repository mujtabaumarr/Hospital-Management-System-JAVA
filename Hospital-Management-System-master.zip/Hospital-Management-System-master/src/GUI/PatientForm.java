package GUI;

import Database.PatientDAO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.time.LocalDate;

//patient form class
public class PatientForm {

    //layout of form established
    public static VBox getForm() {
        VBox container = new VBox();
        container.setAlignment(Pos.CENTER);
        container.setPadding(new Insets(20));
        container.setSpacing(10);

        Label heading = new Label("Create Patient Account");
        heading.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(10);
        grid.setHgap(10);
        grid.setAlignment(Pos.CENTER);

        //add fields and buttons and their labels
        TextField fullNameField = new TextField();
        TextField usernameField = new TextField();
        DatePicker dobPicker = new DatePicker();
        TextField genderField = new TextField();
        TextField addressField = new TextField();
        TextField phoneField = new TextField();
        TextField emailField = new TextField();
        PasswordField passwordField = new PasswordField();
        TextField bloodGroupField = new TextField();
        TextField allergiesField = new TextField();
        TextField diseasesField = new TextField();

        Button submitBtn = new Button("Create Patient");
        submitBtn.setStyle("-fx-background-color: #990000; -fx-text-fill: white;");

        grid.add(new Label("Full Name:"), 0, 0);
        grid.add(fullNameField, 1, 0);

        grid.add(new Label("Username:"), 0, 1);
        grid.add(usernameField, 1, 1);

        grid.add(new Label("Date of Birth:"), 0, 2);
        grid.add(dobPicker, 1, 2);

        grid.add(new Label("Gender (male/female):"), 0, 3);
        grid.add(genderField, 1, 3);

        grid.add(new Label("Address:"), 0, 4);
        grid.add(addressField, 1, 4);

        grid.add(new Label("Phone:"), 0, 5);
        grid.add(phoneField, 1, 5);

        grid.add(new Label("Email:"), 0, 6);
        grid.add(emailField, 1, 6);

        grid.add(new Label("Password:"), 0, 7);
        grid.add(passwordField, 1, 7);

        grid.add(new Label("Blood Group:"), 0, 8);
        grid.add(bloodGroupField, 1, 8);

        grid.add(new Label("Allergies (comma-separated):"), 0, 9);
        grid.add(allergiesField, 1, 9);

        grid.add(new Label("Existing Diseases:"), 0, 10);
        grid.add(diseasesField, 1, 10);

        grid.add(submitBtn, 1, 11);

        submitBtn.setOnAction(e -> { //when submit pressed get all data from fields
            try {
                String fullName = fullNameField.getText();
                String username = usernameField.getText();
                LocalDate dob = dobPicker.getValue();
                String gender = genderField.getText().toLowerCase();
                String address = addressField.getText();
                String phone = phoneField.getText();
                String email = emailField.getText();
                String password = passwordField.getText();
                String bloodGroup = bloodGroupField.getText();
                String allergies = allergiesField.getText();
                String diseases = diseasesField.getText();

                //validation
                if (!(gender.equals("male") || gender.equals("female"))) {
                    showAlert("Invalid Gender", "Please enter male or female.");
                    return;
                }

                //add data to patient db using db method
                PatientDAO.insertPatient(fullName, username, dob, gender, address, phone, email, password,
                        bloodGroup, allergies, diseases);

                showAlert("Success", "Patient account created successfully!");

            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert("Error", "Please enter valid inputs in all fields.");
            }
        });

        container.getChildren().addAll(heading, grid);
        return container;
    }

    //alert helper function
    private static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}