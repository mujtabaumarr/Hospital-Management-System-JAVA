package GUI;

//Importing all dependencies and packages
import Backend.ChatMessage;
import Backend.Doctor;
import Backend.PDFExporter;
import Backend.Patient;
import Database.AssignmentDAO;
import Database.ChatDAO;
import Database.PatientDAO;
import Database.Vitals;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import java.nio.file.Paths;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;


//generates the patient dashboard
public class PatientDashboard {

    //method to get the dashboard and all its gui features to show on the window (starts when user logs in with email)
    public static BorderPane getDashboard(Stage stage, Scene homepageScene, String email) {
        BorderPane layout = new BorderPane();

        //getting patientid for later use through a method implemented later
        int patientId = getPatientIdFromEmail(email);

        //creating the NAV BAR using the CIComponents class's already created method for reusability
        StackPane navBar = UIComponents.createNavBar(stage, homepageScene);

        //implementing the HERO SECTION which is basically just the text displayed bellow the nav bar
        VBox heroBox = new VBox(10);
        heroBox.setPadding(new Insets(30));
        heroBox.setStyle("-fx-background-color: #f2f2f2;");

        Label heroHeading = new Label("Welcome to Your Medical Dashboard");
        heroHeading.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #990000;");
        heroBox.setAlignment(Pos.CENTER);
        heroBox.getChildren().addAll(heroHeading);

        //adding the TILE GRID containing 4 buttons that lead to different pages of the patient dashboard
        GridPane tileGrid = new GridPane();
        tileGrid.setHgap(30);
        tileGrid.setVgap(30);
        tileGrid.setPadding(new Insets(30));
        tileGrid.setAlignment(Pos.CENTER);

        tileGrid.add(createTile("My Vitals", "/GUI/assets/calendar.png", "Access your vitals and upload CSV", () -> {
            //opens vitals window when clicked
            showVitalsWindow(layout, stage, patientId);
        }), 0, 0);

        tileGrid.add(createTile("View Appointments", "/GUI/assets/doctor.png", "Search and view available doctors", () -> {
            //opens appointments window when clicked
            PatientAppointmentsView pav = new PatientAppointmentsView();
            layout.setCenter(pav.getView(stage, homepageScene, patientId));
        }), 1, 0);

        //PANIC BUTTON SECTION
        //email handling class to send email to admin when button pressed:
        class EmailUtil {
            public void sendEmail(String toEmail, String subject, String body) throws Exception {
                // SMTP server setup (Gmail)
                String host = "smtp.gmail.com";  // Change to your SMTP provider if needed
                String fromEmail = "syed.ahmad.ali.2005@gmail.com";  // sender email
                String password = "pooc ryui cjei otue";  // sender email password (uses app-specific password for Gmail)

                Properties props = System.getProperties();
                props.put("mail.smtp.host", host);
                props.put("mail.smtp.port", "587");
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");

                Session session = Session.getInstance(props, new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(fromEmail, password);
                    }
                });

                //Creating email message
                MimeMessage message = new MimeMessage(session);
                message.setFrom(new InternetAddress(fromEmail));
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
                message.setSubject(subject);
                message.setText(body);

                //Sending the email
                Transport.send(message);
                System.out.println("Email sent successfully to " + toEmail);
            }

            //Validating email format
            public static boolean isValidEmail(String email) {
                String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
                return email.matches(emailRegex);
            }
        }
        //adding the actual panic button itself
        UIComponents.FancyButton panicButton = new UIComponents.FancyButton("Panic Button");
        panicButton.setMaxWidth(Double.MAX_VALUE);
        //when pressed sends an alert email to admin and shows alert on screen
        panicButton.setOnAction(e -> {
            if (email == null || !EmailUtil.isValidEmail(email)) {
                showAlert("Invalid Email", "Email address is invalid!");
                return;
            }

            try {
                //message content and subject line with error catching in case email is not prperly delivered
                String subject = "Panic Button Pressed! (TEST ALERT NOT ACTUAL EMERGENCY)";
                String body = "Dear Admin,\n\nYour patient has pressed Panic Button! Please attend to them!\n\nPatient Id: " + patientId + "\n Patient Email: " + email;
                EmailUtil emailUtil = new EmailUtil();
                emailUtil.sendEmail("syed.ahmad.ali.2005@gmail.com", subject, body);
                showAlert("Success", "Alert email sent to Admin!");
            } catch (Exception ex) {
                showAlert("Error", "Failed to send email: " + ex.getMessage());
            }
            //printing to console just for confirmation of functionality
            System.out.println("Panic alert triggered!");
        });
        //setting placement of the button
        HBox panicBox = new HBox(panicButton);
        panicBox.setAlignment(Pos.CENTER);
        panicBox.setPadding(new Insets(10));
        panicBox.setTranslateY(-20);

        //when clicked downloads the report pdf compiling everything from vitals to feedback to prescriptions
        tileGrid.add(createTile("Download Report", "/GUI/assets/guide.png", "Explore patient services and guides", () -> {
            String filePath = Paths.get(System.getProperty("user.home"), "Downloads", "Patient_Report_" + patientId + ".pdf").toString();
            //passing the patients id and the file path to a method that generates the report for download
            boolean success = PDFExporter.exportToPDF(patientId, filePath);
            if (success) {
                System.out.println("PDF exported to: " + filePath);
                try {
                    //try catch block to display any errors on console and leep program running in case pdf export fails
                    java.awt.Desktop.getDesktop().open(new File(filePath));
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            } else {
                System.out.println("PDF export failed.");
            }
        }), 0, 1);
        //when clicked allows user to chat with the doctor
        tileGrid.add(createTile("Chat With Doctor", "/GUI/assets/urgentcare.png", "Get emergency assistance", () -> {
            //calls method in patient database class to get patient id thrpugh te email passed wjen the user logged in
            Patient patient = PatientDAO.getPatientByEmail(email);
            if (patient != null) {
                layout.setCenter(createChatInterface(patient));
            } else {
                System.out.println("Patient not found for email: " + email);
            }
        }), 1, 1);

        //FINAL LAYOUT which adds all the components of the window and sets the size and placement of everythoing
        VBox scrollContent = new VBox();
        scrollContent.getChildren().addAll(heroBox, tileGrid, panicBox);
        scrollContent.setSpacing(20);
        scrollContent.setPadding(new Insets(20));

        ScrollPane scrollPane = new ScrollPane(scrollContent);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: transparent;");

        //seeting the layout so the upper navbar and the rest of the page content are added
        layout.setTop(navBar);
        layout.setCenter(scrollPane);

        return layout;
    }

    //method to get the id from email of user through a sql query on the database
    private static int getPatientIdFromEmail(String email) {
        int id = -1;
        //startin the connection to the database and running the query
        try (Connection conn = Database.DBUtil.getConnection()) {
            //gets the id based on corresponding email
            String query = "SELECT patient_id FROM patients WHERE email = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, email);
            var rs = ps.executeQuery();
            //if query is a success patient_id value assigned to id variable which is then returned
            if (rs.next()) id = rs.getInt("patient_id");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return id;
    }

    //method to create the chat interface
    private static VBox createChatInterface(Patient patient) {
        //layout structure of the page
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setStyle("-fx-background-color: #f5f5f5;");

        //title of the page shown at the top area of the page
        Label title = new Label("Chat with a Doctor");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        //selection dropdown menu to choose which doctor to talk to
        ComboBox<Doctor> doctorCombo = new ComboBox<>();
        doctorCombo.setPromptText("Select a doctor");
        doctorCombo.setPrefWidth(300);

        // Using patient getter metjod to get the patient ID and pass it to getAssignedDoctors() to display doctors for the combobox
        List<Doctor> assignedDoctors = AssignmentDAO.getAssignedDoctors(patient.getPatientId());
        if (assignedDoctors != null && !assignedDoctors.isEmpty()) {
            doctorCombo.getItems().addAll(assignedDoctors);
        } else {
            //if no doctors assigned
            doctorCombo.setDisable(true);
            doctorCombo.setPromptText("No assigned doctors");
        }

        //creating the area for where the messages are shown
        TextArea chatArea = new TextArea();
        chatArea.setEditable(false);
        chatArea.setWrapText(true);
        chatArea.setPrefHeight(400);
        chatArea.setStyle("-fx-control-inner-background: #ecf0f1; -fx-font-size: 14px;");

        //input field to write and send messages
        HBox inputBox = new HBox(10);
        inputBox.setAlignment(Pos.CENTER);
        TextField inputField = new TextField();
        inputField.setPromptText("Type your message...");
        inputField.setPrefWidth(300);
        inputField.setStyle("-fx-background-radius: 8px; -fx-font-size: 14px;");
        Button sendBtn = new Button("Send");
        sendBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-background-radius: 8px;");
        inputBox.getChildren().addAll(inputField, sendBtn);

        final int[] currentDoctorId = {-1};
        final LocalDateTime[] lastMessageTime = {LocalDateTime.MIN};
        final Set<String> displayedMessageIds = new HashSet<>();

        //logic to display who the sender of each message is as well as the read marker and the timestamp of each message
        Timeline messagePoller = new Timeline(new KeyFrame(Duration.seconds(3), ev -> {
            if (currentDoctorId[0] != -1) {
                //getting the message list
                List<ChatMessage> newMessages = ChatDAO.getNewMessages(currentDoctorId[0], patient.getPatientId(), lastMessageTime[0]);

                //adding read marker and timestamp for each msg in the list
                for (ChatMessage msg : newMessages) {
                    String uniqueId = msg.getMessageId() + msg.getTimestamp().toString();
                    if (!displayedMessageIds.contains(uniqueId)) {
                        String sender = msg.getSenderRole().equals("patient") ? "You" : "Doctor";
                        String formattedTime = msg.getTimestamp().toLocalTime().withNano(0).toString();
                        String status = msg.isReadStatus() ? "✓✓" : "✓";

                        chatArea.appendText("[" + formattedTime + "] " + sender + ": " + msg.getMessage() + " " + status + "\n");
                        displayedMessageIds.add(uniqueId);
                        lastMessageTime[0] = msg.getTimestamp();

                        if (!msg.isReadStatus() && !msg.getSenderRole().equals("patient")) {
                            ChatDAO.markMessageAsSeen(msg.getMessageId());
                        }
                    }
                }
            }
        }));
        messagePoller.setCycleCount(Animation.INDEFINITE);
        messagePoller.play();

        //what to do when a doctor has been selected from the combo box
        doctorCombo.setOnAction(e -> {
            Doctor selected = doctorCombo.getValue();
            if (selected != null) {
                chatArea.clear();  // Clear the chat area when a doctor is selected
                displayedMessageIds.clear();
                currentDoctorId[0] = selected.getId();  // Set the selected doctor's ID
                lastMessageTime[0] = LocalDateTime.MIN;

                // Fetch chat history for the selected doctor
                List<ChatMessage> history = ChatDAO.getChatHistory(currentDoctorId[0], patient.getPatientId());
                for (ChatMessage msg : history) {
                    String sender = msg.getSenderRole().equals("doctor") ? "Doctor" : "You";
                    String formattedTime = msg.getTimestamp().toLocalTime().withNano(0).toString();
                    String status = msg.getSenderRole().equals("patient") ? (msg.isReadStatus() ? "✓✓" : "✓") : "";

                    chatArea.appendText("[" + formattedTime + "] " + sender + ": " + msg.getMessage() + " " + status + "\n");
                    displayedMessageIds.add(msg.getMessageId() + msg.getTimestamp().toString());
                    lastMessageTime[0] = msg.getTimestamp();

                    // Mark messages as seen if not already seen
                    if (!msg.isReadStatus() && !msg.getSenderRole().equals("patient")) {
                        ChatDAO.markMessageAsSeen(msg.getMessageId());
                    }
                }
            }
        });

        //send button logic
        sendBtn.setOnAction(e -> {
            String message = inputField.getText().trim();
            if (!message.isEmpty() && currentDoctorId[0] != -1) {
                LocalDateTime now = LocalDateTime.now();
                //taking the text in the input box and using it to pass as a new messafe
                ChatMessage msg = new ChatMessage(
                        patient.getPatientId(),     // Sender ID
                        currentDoctorId[0],         // Receiver ID
                        "patient",                  // Sender Role
                        message,
                        now,
                        false,
                        false
                );
                //sending the message and storing it in database for later referal
                if (ChatDAO.sendMessage(msg)) {
                    chatArea.appendText("[" + now.toLocalTime().withNano(0) + "] You: " + message + " ✓\n");
                    inputField.clear();
                    lastMessageTime[0] = now;
                    displayedMessageIds.add(msg.getMessageId() + now.toString());
                }
            }
        });

        //adding all aspects of the page to the final layout and returning it for displaying on the window when the specific button is called
        layout.getChildren().addAll(title, doctorCombo, chatArea, inputBox);
        return layout;
    }

    //when the vitals tile is pressed:
    private static void showVitalsWindow(BorderPane layout, Stage stage, int patientId) {
        //positioning
        VBox vitalsContent = new VBox(20);
        vitalsContent.setPadding(new Insets(20));
        vitalsContent.setAlignment(Pos.CENTER);

        //labels for page text and heading
        Label title = new Label("Vitals Tracker");
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");

        //upload csv button to allow file upload to read vitals
        Button uploadCSV = new Button("Upload Vitals CSV");
        uploadCSV.setStyle("-fx-background-color: #990000; -fx-text-fill: white; -fx-font-weight: bold;");

        //setting up a table and a line chart to display vitals and trends of those vitals
        TableView<List<String>> vitalsTable = new TableView<>();
        LineChart<String, Number> lineChart = createVitalsLineChart();

        //Date Filter
        HBox filterBox = new HBox(10);
        filterBox.setAlignment(Pos.CENTER);
        Label filterLabel = new Label("Filter by Date Range:");
        DatePicker startDatePicker = new DatePicker();
        DatePicker endDatePicker = new DatePicker();
        Button applyFilterBtn = new Button("Apply Filter");

        filterBox.getChildren().addAll(filterLabel, startDatePicker, endDatePicker, applyFilterBtn);

        //Load and display function (reused)
        Runnable reloadVitals = () -> {
            String start = (startDatePicker.getValue() != null) ? startDatePicker.getValue().toString() : null;
            String end = (endDatePicker.getValue() != null) ? endDatePicker.getValue().toString() : null;
            List<Vitals> vitals = loadVitalsFromDB(patientId, start, end);
            List<List<String>> data = convertVitalsToTableFormat(vitals);
            populateTable(vitalsTable, data);
            populateChart(lineChart, data);
        };

        applyFilterBtn.setOnAction(e -> reloadVitals.run());

        //upload csv logic
        uploadCSV.setOnAction(e -> {
            //opening file chooser so user can select file to upload
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Vitals CSV File");
            File file = fileChooser.showOpenDialog(stage);
            //if file found
            if (file != null) {
                //calling method to read the file and give an array list of vitals
                List<Vitals> vitals = parseVitalsCSV(file, patientId);

                //saving vitals to database
                saveVitalsToDB(vitals, patientId);

                //if the vitals have an alert, show it
                for (Vitals v : vitals) {
                    if (!v.alert.isEmpty()) {
                        showAlert("Alert Detected", "On " + v.date + ": " + v.alert);
                    }
                }
                reloadVitals.run(); //Live update after uploading
            }
        });

        reloadVitals.run(); //Initial loading of vitals when page opened

        //adding the chart, filepicker and table into the page
        vitalsContent.getChildren().addAll(title, filterBox, uploadCSV, vitalsTable, lineChart);
        ScrollPane scrollPane = new ScrollPane(vitalsContent);
        scrollPane.setFitToWidth(true);
        layout.setCenter(scrollPane);
    }

    //method to read the csv file and return arraylist of vitals
    public static List<Vitals> parseVitalsCSV(File file, int patient_Id) {
        List<Vitals> vitals = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            br.readLine(); // skip header
            String line;

            //since csv file should follow a certain structure csv can be read by assuming each value is seperated by a comma and reading value
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                //continue until all 6 values read
                if (parts.length != 6) continue;

                //add each value into a variable
                String date = parts[0].trim();
                int heartRate = Integer.parseInt(parts[1].trim());
                int oxygen = Integer.parseInt(parts[2].trim());
                double temp = Double.parseDouble(parts[3].trim());
                int bpSys = Integer.parseInt(parts[4].trim());
                int bpDia = Integer.parseInt(parts[5].trim());

                //Generate alert string here
                String alert = "";
                if (heartRate < 60 || heartRate > 100) alert += "Abnormal heart rate. ";
                if (oxygen < 90) alert += "Low oxygen level. ";
                if (temp < 36.1 || temp > 37.8) alert += "Abnormal temperature. ";
                if (bpSys < 90 || bpSys > 140) alert += "Systolic pressure out of range. ";
                if (bpDia < 60 || bpDia > 90) alert += "Diastolic pressure out of range. ";

                //add the vitals to a arraylist
                vitals.add(new Vitals(patient_Id ,date, heartRate, oxygen, temp, bpSys, bpDia, alert));
            }
        } catch (Exception e) { //catch exception
            e.printStackTrace();
        }

        //return vitals arraylist once all values added
        return vitals;
    }

    //method to add the vitals to the database by passing patient id and the arraylist containing vitals
    public static void saveVitalsToDB(List<Vitals> vitals, int patientId) {
        //query to run in mysql
        String query = "INSERT INTO vitals (patient_id, date, heart_rate, oxygen, temp, bp_systolic, bp_diastolic, alert) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = Database.DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            //setting values
            for (Vitals v : vitals) {
                ps.setInt(1, patientId);
                ps.setString(2, v.date);
                ps.setInt(3, v.heartRate);
                ps.setInt(4, v.oxygen);
                ps.setDouble(5, v.temp);
                ps.setInt(6, v.bpSys);
                ps.setInt(7, v.bpDia);
                ps.setString(8, v.alert);
                ps.addBatch();
            }
            ps.executeBatch();
        } catch (SQLException e) { //catching exception if db error
            e.printStackTrace();
        }
    }

    //vitals to table method takes arraylist of vitals as parameter
    private static List<List<String>> convertVitalsToTableFormat(List<Vitals> vitals) {
        List<List<String>> data = new ArrayList<>();
        //adding values to table array
        data.add(Arrays.asList("Date", "Heart Rate", "Oxygen", "Temperature", "Systolic", "Diastolic"));
        for (Vitals v : vitals) {
            data.add(Arrays.asList(v.date, String.valueOf(v.heartRate), String.valueOf(v.oxygen),
                    String.valueOf(v.temp), String.valueOf(v.bpSys), String.valueOf(v.bpDia)));
        }
        return data;
    }

    //populating table with values in the table array
    private static void populateTable(TableView<List<String>> table, List<List<String>> data) {
        table.getColumns().clear();
        table.getItems().clear();

        //get data from the array
        List<String> headers = data.get(0);
        for (int i = 0; i < headers.size(); i++) {
            final int colIndex = i;
            TableColumn<List<String>, String> column = new TableColumn<>(headers.get(i));
            column.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().get(colIndex)));
            table.getColumns().add(column);
        }

        for (int i = 1; i < data.size(); i++) {
            table.getItems().add(data.get(i));
        }
    }

    private static LineChart<String, Number> createVitalsLineChart() {
        // Create CategoryAxis for X (String based axis)
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Date");
        yAxis.setLabel("Vital Value");

        // Create the LineChart
        LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("Vitals Trend Over Time");
        lineChart.setMinHeight(300);
        lineChart.setAnimated(false);
        lineChart.setCreateSymbols(true);

        // Add series to chart
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Heart Rate");

        // Add some sample data points
        series.getData().add(new XYChart.Data<>("2024-04-01", 80));
        series.getData().add(new XYChart.Data<>("2024-04-02", 85));
        series.getData().add(new XYChart.Data<>("2024-04-03", 90));
        series.getData().add(new XYChart.Data<>("2024-04-04", 88));

        // Add series to chart
        lineChart.getData().add(series);

        // Adding hover effects to the data points
        for (XYChart.Data<String, Number> dataPoint : series.getData()) {
            Node node = dataPoint.getNode(); // Get the node for each data point
            if (node != null) {
                // Set hover effect
                node.setOnMouseEntered(event -> {
                    // Displaying Tooltip
                    Tooltip tooltip = new Tooltip("Date: " + dataPoint.getXValue() +
                            "\nValue: " + dataPoint.getYValue() +
                            "\nAdditional info...");
                    Tooltip.install(node, tooltip); // Display the tooltip when mouse hovers

                    //Add additional hover effects here
                    node.setStyle("-fx-stroke: #ff0000; -fx-stroke-width: 2; -fx-fill: #ffcc00;");
                });

                node.setOnMouseExited(event -> {
                    // Remove the tooltip when mouse exits
                    Tooltip.uninstall(node, null); // Uninstall the tooltip
                    node.setStyle("-fx-stroke: transparent; -fx-stroke-width: 0; -fx-fill: transparent;");
                });

                //Pop-up Dialog on Mouse Click
                node.setOnMouseClicked(event -> {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Vital Information");
                    alert.setHeaderText("Details for: " + dataPoint.getXValue());
                    alert.setContentText("Date: " + dataPoint.getXValue() +
                            "\nValue: " + dataPoint.getYValue() +
                            "\nAdditional health details.");
                    alert.showAndWait();
                });
            }
        }

        //return the chart
        return lineChart;
    }

    //add values to the chart
    private static void populateChart(LineChart<String, Number> chart, List<List<String>> data) {
        chart.getData().clear();
        List<String> headers = data.get(0);

        for (int col = 1; col < headers.size(); col++) {
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName(headers.get(col));

            for (int row = 1; row < data.size(); row++) {
                try {
                    String date = data.get(row).get(0); // First column is date
                    double yValue = Double.parseDouble(data.get(row).get(col));
                    series.getData().add(new XYChart.Data<>(date, yValue));
                } catch (Exception e) {
                    System.err.println("⚠️ Failed to parse row " + row + ", col " + col + ": " + e.getMessage());
                }
            }

            chart.getData().add(series);
        }
    }

    //reusable method to create a tile design that takes the path to the icon ab utton and text as parameters
    private static VBox createTile(String title, String iconPath, String tooltipText, Runnable onClick) {
        //settinf the size and image of the tile
        ImageView icon = new ImageView(new Image(iconPath));
        icon.setFitWidth(40);
        icon.setFitHeight(40);

        //label of the title and sie elements + color font etc
        Label label = new Label(title);
        label.setStyle("-fx-font-weight: bold; -fx-text-fill: #333;");
        VBox box = new VBox(10, icon, label);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(15));
        box.setStyle("-fx-background-color: white; -fx-border-color: #ddd; -fx-border-radius: 10; -fx-background-radius: 10;");
        box.setPrefSize(150, 150);

        //add the text
        Tooltip.install(box, new Tooltip(tooltipText));

        //expand the icon on mouse hover
        ScaleTransition st = new ScaleTransition(Duration.millis(200), box);
        box.setOnMouseEntered(e -> {
            st.setToX(1.1);
            st.setToY(1.1);
            st.playFromStart();
        });
        box.setOnMouseExited(e -> {
            st.setToX(1.0);
            st.setToY(1.0);
            st.playFromStart();
        });

        //run the relevant action when it is clicked
        box.setOnMouseClicked(e -> onClick.run());

        //return the tile box
        return box;
    }

    //method to show and handle the alerts by taking the title of the alert and the message it displays as parameters
    private static void showAlert(String title, String message) {
        //creates new alert popup
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    //method to load vitals from the database based on the patient id
    private static List<Vitals> loadVitalsFromDB(int patientId, String startDate, String endDate) {
        //array list to store vitals returned by the db
        List<Vitals> vitals = new ArrayList<>();
        //query that runs in mysql
        StringBuilder query = new StringBuilder("SELECT date, heart_rate, oxygen, temp, bp_systolic, bp_diastolic, alert FROM vitals WHERE patient_id = ?");
        if (startDate != null) query.append(" AND date >= ?");
        if (endDate != null) query.append(" AND date <= ?");
        query.append(" ORDER BY date");

        try (Connection conn = Database.DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(query.toString());
            ps.setInt(1, patientId);
            int idx = 2;
            if (startDate != null) ps.setString(idx++, startDate);
            if (endDate != null) ps.setString(idx, endDate);

            var rs = ps.executeQuery();
            //storing the returned values in the array list
            while (rs.next()) {
                String date = rs.getString("date");
                int heartRate = rs.getInt("heart_rate");
                int oxygen = rs.getInt("oxygen");
                double temp = rs.getDouble("temp");
                int bpSys = rs.getInt("bp_systolic");
                int bpDia = rs.getInt("bp_diastolic");
                String alert = rs.getString("alert");
                vitals.add(new Vitals(patientId, date, heartRate, oxygen, temp, bpSys, bpDia, alert));
            }
        } catch (Exception e) {//catching any exceptions that occur
            e.printStackTrace();
        }
        //returning the arraylist
        return vitals;
    }
}