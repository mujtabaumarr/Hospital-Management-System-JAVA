package GUI;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.stage.Stage;

//class to select signup when new user being created
public class SignupSelection {

    //setup the window
    public static Pane getSelectionPane(Stage stage, Scene homepageScene) {
        BorderPane mainLayout = new BorderPane();

        // Reuse nav bar
        StackPane navBar = UIComponents.createNavBar(stage, homepageScene);
        mainLayout.setTop(navBar);

        VBox centerBox = new VBox(20);
        centerBox.setAlignment(Pos.CENTER);

        //on;y patient and admin buttons as only admin can create a doctor account
        UIComponents.FancyButton patientBtn = new UIComponents.FancyButton("Patient Signup");
        UIComponents.FancyButton adminBtn = new UIComponents.FancyButton("Admin Signup");

        //setup actions of buttons (redirect to relevant form classes)
        patientBtn.setOnAction(e -> mainLayout.setCenter(PatientForm.getForm()));
        adminBtn.setOnAction(e -> mainLayout.setCenter(AdminForm.getForm()));

        centerBox.getChildren().addAll(/*doctorBtn,*/ patientBtn, adminBtn);
        mainLayout.setCenter(centerBox);

        return mainLayout;
    }
}