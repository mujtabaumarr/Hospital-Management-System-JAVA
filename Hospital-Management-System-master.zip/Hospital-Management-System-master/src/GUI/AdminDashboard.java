package GUI;

import Backend.Admin;
import Backend.ChatServerManager;
import Backend.Doctor;
import Backend.Patient;
import Database.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.List;

//admin dashboard class
public class AdminDashboard {

    //setting up window and current admin of session
    private static BorderPane root;
    private static Admin currentAdmin;

    //the window gets the dashboard layout
    public static BorderPane getDashboard(Stage primaryStage, Scene homepageScene ,String adminEmail) {
        try {
            currentAdmin = AdminDAO.getAdminByEmail(adminEmail);
        } catch (Exception e) {
            System.out.println("Error retrieving admin: " + e.getMessage());
        }

        root = new BorderPane();
        root.setPadding(new Insets(0)); // Set 0 padding to align with navbar

        // Navbar at top
        //StackPane navBar = createAdminNavBar(primaryStage);
        StackPane navBar = UIComponents.createNavBar(primaryStage, homepageScene);
        root.setTop(navBar);

        // Header and buttons
        Text header = new Text("Administrator Dashboard");
        header.setFont(Font.font("Arial", FontWeight.BOLD, 28));

        VBox buttonBox = new VBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(40));

        //buttons for different functions of the dashboard that redirect to other windows
        buttonBox.getChildren().addAll(
                createButton("View All Users", AdminDashboard::openViewUsers),
                createButton("Add New Doctor", AdminDashboard::openAddDoctor),
                createButton("Add New Patient", AdminDashboard::openAddPatient),
                createButton("Remove User", AdminDashboard::openRemoveUser),
                createButton("View System Summary", AdminDashboard::openSystemSummary)
        );

        VBox layout = new VBox(30, header, buttonBox);
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setPadding(new Insets(30));

        root.setCenter(layout);
        return root;
    }

    //method for reusable stylised button
    private static UIComponents.FancyButton createButton(String text, Runnable action) {
        UIComponents.FancyButton button = new UIComponents.FancyButton(text);
        button.setPrefWidth(300); // Optional override
        button.setOnAction(e -> action.run());
        return button;
    }

    //method that is called when view users pressed
    private static void openViewUsers() {
        //setup and position user list and write title
        VBox userList = new VBox(10);
        userList.setPadding(new Insets(20));
        userList.setAlignment(Pos.TOP_LEFT);

        Text title = new Text("All Users");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        userList.getChildren().add(title);

        boolean noUsers = true;

        //get users from respective user database classes and store in array list
        try {
            // Patients
            List<Patient> patients = PatientDAO.getAllPatients();
            if (!patients.isEmpty()) {
                noUsers = false;
                for (Patient p : patients) {
                    Label label = createUserLabel("[Patient]", String.valueOf(p.getPatientId()), p.getName(), p.getEmail());
                    userList.getChildren().add(label);
                }
            }

            //same with Doctors
            List<Doctor> doctors = DoctorDAO.getAllDoctors();
            if (!doctors.isEmpty()) {
                noUsers = false;
                for (Doctor d : doctors) {
                    Label label = createUserLabel("[Doctor]",String.valueOf(d.getId()), d.getFullName(), d.getEmail());
                    userList.getChildren().add(label);
                }
            }

            //same with Admins
            List<Admin> admins = AdminDAO.getAllAdmins();
            if (!admins.isEmpty()) {
                noUsers = false;
                for (Admin a : admins) {
                    Label label = createUserLabel("[Admin]", String.valueOf(a.getId()), a.getFullName(), a.getEmail());
                    userList.getChildren().add(label);
                }
            }

        } catch (Exception e) { //if error occurs during db data geting
            Label error = new Label("Error retrieving users: " + e.getMessage());
            error.setTextFill(Color.RED);
            userList.getChildren().add(error);
        }

        if (noUsers) { //if no users in system yet
            Label empty = new Label("No users in the system yet.");
            empty.setFont(Font.font(16));
            userList.getChildren().add(empty);
        }

        ScrollPane scrollPane = new ScrollPane(userList);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: #ffffff;");

        root.setCenter(scrollPane);
    }

    //calls method to open add doctor window when button pressed
    private static void openAddDoctor() {
        root.setCenter(DoctorForm.getForm());
    }

    //same with add patint button press
    private static void openAddPatient() {
        root.setCenter(PatientForm.getForm());
    }

    //when remove user called
    private static void openRemoveUser() {
        //setup position of data entry that user enters to remove the user based on
        VBox container = new VBox(15);
        container.setPadding(new Insets(30));
        container.setAlignment(Pos.TOP_CENTER);

        //title
        Text title = new Text("Remove a User");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));

        //enter email input box
        Label idLabel = new Label("Enter User Email:");
        TextField emailField = new TextField();
        emailField.setPromptText("e.g. john@example.com");

        //role combo box
        Label roleLabel = new Label("Select User Role:");
        ComboBox<String> roleCombo = new ComboBox<>();
        roleCombo.getItems().addAll("Patient", "Doctor", "Admin");

        //button to remove the user
        Button removeBtn = new Button("Remove User");
        Label resultLabel = new Label();

        //whne button pressed, check if user is valid and then delet from db using user respective db classes
        removeBtn.setOnAction(e -> {
            String email = emailField.getText();
            String role = roleCombo.getValue();

            if (email.isEmpty() || role == null) {
                resultLabel.setText("Please provide both email and role.");
                resultLabel.setTextFill(Color.RED);
                return;
            }

            boolean success = false;

            try {
                switch (role) {
                    case "Patient":
                        success = PatientDAO.deletePatientByEmail(email);
                        break;
                    case "Doctor":
                        success = DoctorDAO.deleteDoctorByEmail(email);
                        break;
                    case "Admin":
                        success = AdminDAO.deleteAdminByEmail(email);
                        break;
                }

                if (success) {
                    resultLabel.setText("User removed successfully.");
                    resultLabel.setTextFill(Color.GREEN);
                } else {
                    resultLabel.setText("User not found or could not be deleted.");
                    resultLabel.setTextFill(Color.RED);
                }

            } catch (Exception ex) {
                resultLabel.setText("Error: " + ex.getMessage());
                resultLabel.setTextFill(Color.RED);
            }
        });

        container.getChildren().addAll(title, idLabel, emailField, roleLabel, roleCombo, removeBtn, resultLabel);
        root.setCenter(container);
    }

    //opens system summary window when called
    private static void openSystemSummary() {
        VBox container = new VBox(15);
        container.setPadding(new Insets(30));
        container.setAlignment(Pos.TOP_CENTER);

        //title
        Text title = new Text("System Summary");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 28));

        try {
            // Get counts using DAO
            int doctorCount = DoctorDAO.getAllDoctors().size();
            int patientCount = PatientDAO.getAllPatients().size();
            int adminCount = AdminDAO.getAllAdmins().size();

            int totalAppointments = AppointmentDAO.getAllAppointments().size(); // Assuming you have this
            int totalVitals = Vitals.getAllVitals().size(); // Assuming you have this

            // Display
            Label adminLabel = new Label("Logged-in Admin: " + currentAdmin.getFullName() + " (ID: " + currentAdmin.getId() + ")");
            Label adminCountLabel = new Label("Total Admins: " + adminCount);
            Label doctorLabel = new Label("Total Doctors: " + doctorCount);
            Label patientLabel = new Label("Total Patients: " + patientCount);
            Label appointmentLabel = new Label("Total Appointments: " + totalAppointments);
            Label vitalsLabel = new Label("Total Vital Sign Records: " + totalVitals);

            for (Label label : List.of(adminLabel, adminCountLabel, doctorLabel, patientLabel, appointmentLabel, vitalsLabel)) {
                label.setFont(Font.font("Arial", 16));
            }

            container.getChildren().addAll(title, adminLabel, adminCountLabel, doctorLabel, patientLabel, appointmentLabel, vitalsLabel);
        } catch (Exception e) {
            Label error = new Label("Error retrieving summary: " + e.getMessage());
            error.setTextFill(Color.RED);
            container.getChildren().add(error);
        }

        root.setCenter(container); //'root' is main BorderPane
    }

    //method to create a new user, called when creating a doctor or patient account
    private static Label createUserLabel(String role, String id, String name, String email) {
        Label userLabel = new Label(role + " " + id + ": " + name + " - " + email);
        userLabel.setFont(Font.font("Arial", 16));
        userLabel.setStyle("-fx-background-color: #f0f0f0; -fx-padding: 10px; -fx-background-radius: 8;");
        return userLabel;
    }
}