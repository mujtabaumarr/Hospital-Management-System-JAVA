package GUI;

import Database.DoctorDAO;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.time.LocalDate;

//doctor form class
public class DoctorForm {

    //sets up window
    public static VBox getForm() {
        VBox container = new VBox();
        container.setAlignment(Pos.CENTER);
        container.setPadding(new Insets(20));
        container.setSpacing(10);

        Label heading = new Label("Create Doctor Account");
        heading.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setVgap(10);
        grid.setHgap(10);
        grid.setAlignment(Pos.CENTER);

        //all text fields
        TextField fullNameField = new TextField();
        TextField usernameField = new TextField();
        DatePicker dobPicker = new DatePicker();
        TextField genderField = new TextField();
        TextField addressField = new TextField();
        TextField phoneField = new TextField();
        TextField emailField = new TextField();
        PasswordField passwordField = new PasswordField();
        TextField pmdcField = new TextField();
        TextField availabilityField = new TextField();
        TextField salaryField = new TextField();
        TextField qualificationField = new TextField();
        TextField specialityField = new TextField();
        TextField experienceField = new TextField();

        Button submitBtn = new Button("Create Doctor");
        submitBtn.setStyle("-fx-background-color: #990000; -fx-text-fill: white;");

        //add all elements to window
        grid.add(new Label("Full Name:"), 0, 0);
        grid.add(fullNameField, 1, 0);

        grid.add(new Label("Username:"), 0, 1);
        grid.add(usernameField, 1, 1);

        grid.add(new Label("Date of Birth:"), 0, 2);
        grid.add(dobPicker, 1, 2);

        grid.add(new Label("Gender (male/female):"), 0, 3);
        grid.add(genderField, 1, 3);

        grid.add(new Label("Address:"), 0, 4);
        grid.add(addressField, 1, 4);

        grid.add(new Label("Phone:"), 0, 5);
        grid.add(phoneField, 1, 5);

        grid.add(new Label("Email:"), 0, 6);
        grid.add(emailField, 1, 6);

        grid.add(new Label("Password:"), 0, 7);
        grid.add(passwordField, 1, 7);

        grid.add(new Label("PMDC No:"), 0, 8);
        grid.add(pmdcField, 1, 8);

        grid.add(new Label("Availability Hours:"), 0, 9);
        grid.add(availabilityField, 1, 9);

        grid.add(new Label("Salary:"), 0, 10);
        grid.add(salaryField, 1, 10);

        grid.add(new Label("Qualification:"), 0, 11);
        grid.add(qualificationField, 1, 11);

        grid.add(new Label("Speciality:"), 0, 12);
        grid.add(specialityField, 1, 12);

        grid.add(new Label("Experience (years):"), 0, 13);
        grid.add(experienceField, 1, 13);

        grid.add(submitBtn, 1, 14);

        submitBtn.setOnAction(e -> { //when submitted, get data from fields
            try {
                String fullName = fullNameField.getText();
                String username = usernameField.getText();
                LocalDate dob = dobPicker.getValue();
                String gender = genderField.getText().toLowerCase();
                String address = addressField.getText();
                String phone = phoneField.getText();
                String email = emailField.getText();
                String password = passwordField.getText();
                String pmdc = pmdcField.getText();
                String availability = availabilityField.getText();
                String salaryText = salaryField.getText();
                String qualification = qualificationField.getText();
                String speciality = specialityField.getText();
                String experience = experienceField.getText();

                //validate data entry
                if (dob == null) {
                    showAlert("Invalid Input", "Please select a valid Date of Birth.");
                    return;
                }

                if (!(gender.equals("male") || gender.equals("female"))) {
                    showAlert("Invalid Gender", "Please enter 'male' or 'female'.");
                    return;
                }

                if (fullName.isEmpty() || username.isEmpty() || gender.isEmpty() || address.isEmpty() ||
                        phone.isEmpty() || email.isEmpty() || password.isEmpty() || pmdc.isEmpty() ||
                        availability.isEmpty() || salaryText.isEmpty() ||
                        qualification.isEmpty() || speciality.isEmpty() || experience.isEmpty()) {

                    showAlert("Missing Fields", "Please fill all fields before submitting.");
                    return;
                }

                double salary = Double.parseDouble(salaryText);

                //insert data into db
                DoctorDAO.insertDoctor(fullName, username, dob, gender, address, phone, email, password,
                        pmdc, availability, salary, qualification, speciality, experience);

                showAlert("Success", "Doctor account created successfully!");

            } catch (NumberFormatException nfe) { //catch errors
                showAlert("Invalid Input", "Salary must be a valid number.");
            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert("Error", "An unexpected error occurred. Please check your inputs.");
            }
        });

        container.getChildren().addAll(heading, grid);
        return container;
    }

    //reusable alert helper method to manage generated alerts
    public static void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}