package Backend;

//class user to serve as base for all other user types (admin, doctor, patient)
public class User {
    //attributes common to all users
    private String username;
    private String gender;

    //constructor
    public User(String username, String gender) {
        this.username = username;
        this.gender = gender;
    }

    //no args constructor
    public User() {
    }

    //getter setters
    public String getUsername() {
        return username;
    }

    public String getGender() {
        return gender;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
