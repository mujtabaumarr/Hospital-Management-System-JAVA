package Backend;

import java.time.LocalDate;

//feedback class to hold structure of feednack given by doctors to patients
public class Feedback {
    //attributes
    private int doctorId;
    private int patientId;
    private LocalDate feedbackDate;
    private String feedback;

    //constructor
    public Feedback(int doctorId, int patientId, LocalDate feedbackDate, String feedback) {
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.feedbackDate = feedbackDate;
        this.feedback = feedback;
    }
    //getter setters
    public int getDoctorId() { return doctorId; }
    public int getPatientId() { return patientId; }
    public LocalDate getFeedbackDate() { return feedbackDate; }
    public String getFeedback() { return feedback; }
}