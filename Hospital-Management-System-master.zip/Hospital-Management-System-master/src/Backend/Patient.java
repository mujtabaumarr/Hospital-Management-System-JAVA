package Backend; // or whatever your model package is

import java.util.ArrayList;
import java.util.List;

//patient class inherits user class and holds patient user structure
public class Patient extends User{
    private int patientId;
    private String name;
    private String username;
    private String dob;
    private String gender;
    private String address;
    private String phone;
    private String email;
    private String password;
    private String bloodGroup;
    private String allergies;
    private String diseases;

    // New field to track availability
    private boolean isAvailable;

    // List of patients (if this is used somewhere, you can leave it)
    private List<Patient> patients = new ArrayList<>();

    // Getters and Setters
    public  int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public List<Patient> getPatients() {
        return patients;
    }

    public void setPatients(List<Patient> patients) {
        this.patients = patients;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getDob() { return dob; }
    public void setDob(String dob) { this.dob = dob; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getAllergies() { return allergies; }
    public void setAllergies(String allergies) { this.allergies = allergies; }

    public String getDiseases() { return diseases; }
    public void setDiseases(String diseases) { this.diseases = diseases; }

    // Getter and Setter for availability status
    public boolean isAvailable() { return isAvailable; }
    public void setAvailable(boolean isAvailable) { this.isAvailable = isAvailable; }

    @Override
    public String toString() {
        //Appending availability status in the toString() method for the ComboBox display
        return name + " (ID: " + patientId + ") " + (isAvailable ? "(Available)" : "(Not Available)");
    }
}