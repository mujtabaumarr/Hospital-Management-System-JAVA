package Backend;

import Database.PrescriptionDAO;
import Database.AppointmentDAO;
import Database.FeedbackDAO;

import Backend.Appointment;
import Backend.Prescription;
import Backend.Feedback;
import Database.Vitals;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

//class to export and generate a patient report to a pdf (uses pdfbox dependancy)
public class PDFExporter {

    //exporting to pdf method takes patient id and filepath to where to store pdf as parameters
    public static boolean exportToPDF(int patientId, String filePath) {
        //getting vitals list for that patient using patient id
        List<Vitals> vitalsList = Vitals.getAllVitals(patientId);

        //getting prescriptions list for that patient from db using patient id
        List<Prescription> prescriptionsList = PrescriptionDAO.getPrescriptionsByPatientId(patientId);

        //getting a list of feedback of thta patient from db using patient id
        List<Database.FeedbackDAO> rawList = FeedbackDAO.getFeedbackList(patientId);
        List<Backend.Feedback> feedbackList = new ArrayList<>();

        //giving structure to the feedback
        for (Database.FeedbackDAO f : rawList) {
            String doctorName = f.getDoctorName();
            String feedbackText = f.getFeedback();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate feedbackDate = LocalDate.parse(f.getDate(), dtf);

            int doctorId = getDoctorIdByName(doctorName);

            Backend.Feedback feedbackObj = new Backend.Feedback(
                    doctorId,
                    patientId,
                    feedbackDate,
                    feedbackText
            );

            feedbackList.add(feedbackObj);
        }

        //getting the appointments of that specific patient in a list from db
        List<AppointmentDAO.shownAppointment> appointmentsList = AppointmentDAO.getAppointmentsForPatient(patientId);

        //adding data to the pdf
        try (PDDocument document = new PDDocument()) {
            //creating the page
            PDPage page = new PDPage();
            document.addPage(page);

            //font
            PDType1Font font = new PDType1Font(Standard14Fonts.FontName.HELVETICA);

            PDPageContentStream contentStream = new PDPageContentStream(document, page);
            float yPosition = 750;
            float leading = 20f;

            //header
            contentStream.beginText();
            contentStream.setFont(font, 18);
            contentStream.newLineAtOffset(50, yPosition);
            contentStream.showText("Patient Report");
            yPosition -= leading * 2;

            //vitals
            contentStream.setFont(font, 12);
            contentStream.newLineAtOffset(0, -leading);
            contentStream.showText("=== Vitals ===");

            for (Vitals vitals : vitalsList) {
                String vitalsText = "• Date: " + vitals.getDate() +
                        " | Heart Rate: " + vitals.getHeartRate() +
                        " | BP: " + vitals.getBpSys() + "/" + vitals.getBpDia() +
                        " | O2: " + vitals.getOxygen() +
                        " | Temp: " + vitals.getTemp();

                yPosition -= leading;
                if (yPosition < 50) {
                    contentStream.endText();
                    contentStream.close();
                    page = new PDPage();
                    document.addPage(page);
                    contentStream = new PDPageContentStream(document, page);
                    yPosition = 750;
                    contentStream.beginText();
                    contentStream.setFont(font, 12);
                    contentStream.newLineAtOffset(50, yPosition);
                }
                contentStream.newLineAtOffset(0, -leading);
                contentStream.showText(vitalsText);
            }

            //prescriptions
            yPosition -= leading * 2;
            contentStream.newLineAtOffset(0, -leading);
            contentStream.showText("=== Prescriptions ===");

            for (Prescription prescription : prescriptionsList) {
                String prescripText = "• Medicine: " + prescription.getMedicineName() +
                        " | Dosage: " + prescription.getDosage() +
                        " | From: " + prescription.getStartDate() +
                        " to " + prescription.getEndDate();

                yPosition -= leading;
                if (yPosition < 50) {
                    contentStream.endText();
                    contentStream.close();
                    page = new PDPage();
                    document.addPage(page);
                    contentStream = new PDPageContentStream(document, page);
                    yPosition = 750;
                    contentStream.beginText();
                    contentStream.setFont(font, 12);
                    contentStream.newLineAtOffset(50, yPosition);
                }
                contentStream.newLineAtOffset(0, -leading);
                contentStream.showText(prescripText);
            }

            //doctor feedback
            yPosition -= leading * 2;
            contentStream.newLineAtOffset(0, -leading);
            contentStream.showText("=== Doctor Feedback ===");

            for (Feedback feedback : feedbackList) {
                String feedbackText = "• Doctor ID: " + feedback.getDoctorId() +
                        " | Date: " + feedback.getFeedbackDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) +
                        " | Feedback: " + feedback.getFeedback();

                yPosition -= leading;
                if (yPosition < 50) {
                    contentStream.endText();
                    contentStream.close();
                    page = new PDPage();
                    document.addPage(page);
                    contentStream = new PDPageContentStream(document, page);
                    yPosition = 750;
                    contentStream.beginText();
                    contentStream.setFont(font, 12);
                    contentStream.newLineAtOffset(50, yPosition);
                }
                contentStream.newLineAtOffset(0, -leading);
                contentStream.showText(feedbackText);
            }

            //appointments
            yPosition -= leading * 2;
            contentStream.newLineAtOffset(0, -leading);
            contentStream.showText("=== Appointments ===");

            for (AppointmentDAO.shownAppointment appointment : appointmentsList) {
                String appointmentText = "• Doctor ID: " + appointment.getDoctorId() +
                        " | Date: " + appointment.getDate() +
                        " | Time: " + appointment.getTime();

                yPosition -= leading;
                if (yPosition < 50) {
                    contentStream.endText();
                    contentStream.close();
                    page = new PDPage();
                    document.addPage(page);
                    contentStream = new PDPageContentStream(document, page);
                    yPosition = 750;
                    contentStream.beginText();
                    contentStream.setFont(font, 12);
                    contentStream.newLineAtOffset(50, yPosition);
                }
                contentStream.newLineAtOffset(0, -leading);
                contentStream.showText(appointmentText);
            }

            contentStream.endText();
            contentStream.close();

            document.save(new File(filePath));
            return true;

        } catch (IOException e) {//catch errors whether in printing to pdf or getting data from db
            e.printStackTrace();
            return false;
        }
    }

    //method takes doctor name as parameter and returns id from db
    private static int getDoctorIdByName(String doctorName) {
        int doctorId = -1;
        //query passed to db
        String query = "SELECT doctor_id FROM doctors WHERE full_name = ?";

        try (Connection conn = Database.DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, doctorName);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                //set data from db to local variable
                doctorId = rs.getInt("doctor_id");
            }

        } catch (Exception e) {//catch db error
            e.printStackTrace();
        }

        //return the id
        return doctorId;
    }
}