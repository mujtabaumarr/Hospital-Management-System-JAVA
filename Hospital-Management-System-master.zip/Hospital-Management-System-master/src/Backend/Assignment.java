package Backend;

//assignment class to store the links between doctors and patients
public class Assignment {
    private int doctorId;
    private int patientId;

    // Default constructor
    public Assignment() {}

    // Constructor with parameters
    public Assignment(int doctorId, int patientId) {
        this.doctorId = doctorId;
        this.patientId = patientId;
    }

    // Getter and Setter for doctorId
    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    // Getter and Setter for patientId
    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    //tostring for better readability if needed
    @Override
    public String toString() {
        return "Assignment [doctorId=" + doctorId + ", patientId=" + patientId + "]";
    }
}