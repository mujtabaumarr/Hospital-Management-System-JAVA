package Backend;

import java.time.LocalDate;
import java.util.List;

//docotr class to store doctor info and structure, inherits user class
public class Doctor extends User{
    private int id;
    private String fullName;
    private String username;
    private LocalDate dob;  // Changed from String to LocalDate
    private String gender;
    private String address;
    private String phone;
    private String email;
    private String password;
    private String pmdcNumber;
    private String availabilityHours;
    private double salary;
    private String qualification;
    private String speciality;
    private String experience;
    private List<Patient> patients; // If doctor has assigned patients

    // Constructor
    public Doctor() {}

        // Getters and Setters
        public int getId () {
            return id;
        }
        public void setId ( int id){
            this.id = id;
        }

        public String getFullName () {
            return fullName;
        }
        public void setFullName (String fullName){
            this.fullName = fullName;
        }

        public String getUsername () {
            return username;
        }
        public void setUsername (String username){
            this.username = username;
        }

        public LocalDate getDob () {
            return dob;
        }
        public void setDob (LocalDate dob){
            this.dob = dob;
        }

        public String getGender () {
            return gender;
        }
        public void setGender (String gender){
            this.gender = gender;
        }

        public String getAddress () {
            return address;
        }
        public void setAddress (String address){
            this.address = address;
        }

        public String getPhone () {
            return phone;
        }
        public void setPhone (String phone){
            this.phone = phone;
        }

        public String getEmail () {
            return email;
        }
        public void setEmail (String email){
            this.email = email;
        }

        public String getPassword () {
            return password;
        }
        public void setPassword (String password){
            this.password = password;
        }

        public String getPmdcNumber () {
            return pmdcNumber;
        }
        public void setPmdcNumber (String pmdcNumber){
            this.pmdcNumber = pmdcNumber;
        }

        public String getAvailabilityHours () {
            return availabilityHours;
        }
        public void setAvailabilityHours (String availabilityHours){
            this.availabilityHours = availabilityHours;
        }

        public double getSalary () {
            return salary;
        }
        public void setSalary ( double salary){
            this.salary = salary;
        }

        public String getQualification () {
            return qualification;
        }
        public void setQualification (String qualification){
            this.qualification = qualification;
        }

        public String getSpeciality () {
            return speciality;
        }
        public void setSpeciality (String speciality){
            this.speciality = speciality;
        }

        public String getExperience () {
            return experience;
        }
        public void setExperience (String experience){
            this.experience = experience;
        }

        public List<Patient> getPatients () {
            return patients;
        }
        public void setPatients (List < Patient > patients) {
            this.patients = patients;
        }

        //to string if clean output on console is ever needed
        @Override
        public String toString () {
            return "Doctor{" +
                    "id=" + id +
                    ", fullName='" + fullName + '\'' +
                    ", username='" + username + '\'' +
                    ", email='" + email + '\'' +
                    ", speciality='" + speciality + '\'' +
                    '}';
        }
    }
