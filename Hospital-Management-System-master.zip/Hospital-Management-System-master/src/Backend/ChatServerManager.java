package Backend;

import java.util.Map;
import java.util.Scanner;

//chat server class to test chat features in console
public class ChatServerManager {

    //scanner to read input from console
    private static Scanner scanner = new Scanner(System.in);

    //main menu method for managing chat server
    public static void manage() {
        while (true) {
            //print menu options
            System.out.println("\n===== CHAT SERVER MANAGEMENT =====");
            System.out.println("1. View Doctor-Patient Relationships");
            System.out.println("2. Validate Doctor-Patient Relationship");
            System.out.println("3. Return to Admin Menu");
            System.out.print("Select an option: ");

            //read user input
            int choice = getIntInput();

            //handle user choice
            switch (choice) {
                case 1 -> viewDoctorPatientRelationships(); //option to view all doctor-patient links
                case 2 -> validateDoctorPatientRelationship(); //option to check specific link
                case 3 -> { return; } //exit to admin menu
                default -> System.out.println("Invalid choice. Try again."); //invalid input handling
            }
        }
    }

    //method to display doctor-patient relationships
    private static void viewDoctorPatientRelationships() {
        //get doctor and patient mapping from database
        Map<String, Doctor> doctorMap = Database.ChatServerDAO.getAllDoctorsWithPatients();

        //check if there are any doctors
        if (doctorMap.isEmpty()) {
            System.out.println("No doctors found in the system.");
            return;
        }

        boolean found = false;
        //iterate through each doctor
        for (Doctor doctor : doctorMap.values()) {
            System.out.println("Doctor: " + doctor.getFullName() + " (ID: " + doctor.getId() + ")");
            //check if doctor has any patients
            if (doctor.getPatients().isEmpty()) {
                System.out.println("  - No patients assigned.");
            } else {
                //print each assigned patient
                for (Patient p : doctor.getPatients()) {
                    System.out.println("  - Patient: " + p.getName() + " (ID: " + p.getPatientId() + ")");
                    found = true;
                }
            }
            System.out.println();
        }

        //if no relationships were found
        if (!found) {
            System.out.println("No doctor-patient relationships established.");
        }
    }

    //method to check if a specific doctor-patient relationship exists
    private static void validateDoctorPatientRelationship() {
        System.out.print("Enter doctor ID: ");
        String doctorId = scanner.nextLine();

        System.out.print("Enter patient ID: ");
        String patientId = scanner.nextLine();

        //validate using database method
        if (Database.ChatServerDAO.relationshipExists(doctorId, patientId)) {
            System.out.println("VALID: The doctor-patient relationship exists.");
        } else {
            System.out.println("INVALID: No such relationship exists.");
        }
    }

    //helper method to safely parse integer input
    private static int getIntInput() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (Exception e) {
            return -1;
        }
    }
}
