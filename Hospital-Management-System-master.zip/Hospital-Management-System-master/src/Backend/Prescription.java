package Backend;

import java.time.LocalDate;

//prescription class to store structure of each prescription given by doctor
public class Prescription {
    //attributes
    private int medicationId;
    private int patientId;
    private int doctorId;
    private String medicineName;
    private String dosage;
    private LocalDate startDate;
    private LocalDate endDate;

    //constructor
    public Prescription(int medicationId, int patientId, int doctorId, String medicineName, String dosage, LocalDate startDate, LocalDate endDate) {
        this.medicationId = medicationId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.medicineName = medicineName;
        this.dosage = dosage;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // Getters
    public int getMedicationId() { return medicationId; }
    public int getPatientId() { return patientId; }
    public int getDoctorId() { return doctorId; }
    public String getMedicineName() { return medicineName; }
    public String getDosage() { return dosage; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
}