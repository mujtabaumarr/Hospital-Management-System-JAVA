package Backend;
//importing to store date
import java.time.LocalDate;

//admin class that inherits user class
public class Admin extends User{
    //attributes
    private int id;
    private String fullName;
    private String username;
    private LocalDate dob;
    private String gender;
    private String address;
    private String phone;
    private String email;
    private String password;
    private String position;
    private String department;
    private double salary;

    // No-arg constructor (required for resultSet mapping)
    public Admin() {
    }

    // Partial constructor (used in getAdminByEmail)
    public Admin(int id, String fullName, String email, String password) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.password = password;
    }

    // Full constructor (optional if needed to instantiate everything at once)
    public Admin(int id, String fullName, String username, LocalDate dob, String gender,
                 String address, String phone, String email, String password,
                 String position, String department, double salary) {
        this.id = id;
        this.fullName = fullName;
        this.username = username;
        this.dob = dob;
        this.gender = gender;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.password = password;
        this.position = position;
        this.department = department;
        this.salary = salary;
    }

    //setters and getters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}